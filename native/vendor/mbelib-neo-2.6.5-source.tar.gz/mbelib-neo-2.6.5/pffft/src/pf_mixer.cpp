/*
This software is part of pffft/pfdsp, a set of simple DSP routines.

Copyright (c) 2014, Andras Retzler <randras@sdr.hu>
Copyright (c) 2020  Hayati Ayguen <h_ayguen@web.de>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the copyright holder nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ANDRAS RETZLER BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* include own header first, to see missing includes */
#include "pf_mixer.h"
#include "fmv.h"

#include <math.h>
#include <stdlib.h>
#include <assert.h>

//they dropped M_PI in C99, so we define it:
#define PI ((float)3.14159265358979323846)

//apply to pointers:
#define iof(complexf_input_p,i) (*(((float*)complexf_input_p)+2*(i)))
#define qof(complexf_input_p,i) (*(((float*)complexf_input_p)+2*(i)+1))

#define USE_ALIGNED_ADDRESSES  0



/*
  _____   _____ _____      __                  _   _
 |  __ \ / ____|  __ \    / _|                | | (_)
 | |  | | (___ | |__) |  | |_ _   _ _ __   ___| |_ _  ___  _ __  ___
 | |  | |\___ \|  ___/   |  _| | | | '_ \ / __| __| |/ _ \| '_ \/ __|
 | |__| |____) | |       | | | |_| | | | | (__| |_| | (_) | | | \__ \
 |_____/|_____/|_|       |_|  \__,_|_| |_|\___|\__|_|\___/|_| |_|___/

*/


#if defined(__GNUC__)
#  define ALWAYS_INLINE(return_type) inline return_type __attribute__ ((always_inline))
#  define RESTRICT __restrict
#elif defined(_MSC_VER)
#  define ALWAYS_INLINE(return_type) __forceinline return_type
#  define RESTRICT __restrict
#endif


#ifndef PFFFT_SIMD_DISABLE
/* 32-bit x86: __i386__, not i386, which strict -std=c++11 does not define;
   and only when SSE is enabled (-msse, MSVC /arch:SSE or higher) */
#if (defined(__x86_64__) || defined(_M_X64) || defined(__SSE__) || (defined(_M_IX86_FP) && _M_IX86_FP >= 1))
  #include <xmmintrin.h>
  #define HAVE_SSE_INTRINSICS 1

/* sse2neon.h supports exactly AArch64 and ARMv7-A, each with NEON enabled,
   and not Windows (clang-cl): its _mm_malloc() needs posix_memalign() */
#elif !defined(_WIN32) && \
      ((defined(__aarch64__) && defined(__ARM_NEON)) || \
       (defined(__arm__) && __ARM_ARCH == 7 && defined(__ARM_NEON) && defined(__ARM_NEON__)))
  /* the vendored sse2neon.h is not clean under -Wall -Wextra -pedantic:
     GCC-only target pragmas, an intentionally uninitialized
     _mm_undefined_ps(), C99 compound literals and designated initializers,
     and type-punned pointer casts (GCC on ARMv7) */
  #if defined(__clang__)
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunknown-pragmas"
    #pragma clang diagnostic ignored "-Wuninitialized"
    #pragma clang diagnostic ignored "-Wpedantic"
    #if __has_warning("-Wc99-designator")
      #pragma clang diagnostic ignored "-Wc99-designator"
    #endif
  #elif defined(__GNUC__)
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wuninitialized"
    #pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
    #pragma GCC diagnostic ignored "-Wpedantic"
    #pragma GCC diagnostic ignored "-Wstrict-aliasing"
  #endif
  #include "sse2neon.h"
  #if defined(__clang__)
    #pragma clang diagnostic pop
  #elif defined(__GNUC__)
    #pragma GCC diagnostic pop
  #endif
  #define HAVE_SSE_INTRINSICS 1

#endif
#endif

#ifdef HAVE_SSE_INTRINSICS

typedef __m128 v4sf;
#  define SIMD_SZ 4

typedef union v4_union {
  __m128  v;
  float f[4];
} v4_union;

#define VMUL(a,b)                 _mm_mul_ps(a,b)
#define VDIV(a,b)                 _mm_div_ps(a,b)
#define VADD(a,b)                 _mm_add_ps(a,b)
#define VSUB(a,b)                 _mm_sub_ps(a,b)
/* Fused multiply-add, where the target guarantees a real FMA instruction.
   On x86 see simd/pf_fma_x86.h for why the test is not just __FMA__.
   On AArch64 the _mm_* names above come from sse2neon.h, whose _mm_fmadd_ps
   maps onto vfmaq_f32; it has no _mm_fnmadd_ps, so VMSUB stays portable there.
   Everything else falls back to a separate multiply and add, exactly what
   these call sites spelled out before. */
#include "simd/pf_fma_x86.h"
#ifdef PFFFT_X86_HAVE_FMA
#  include <immintrin.h>
#  define VMADD(a,b,c)            _mm_fmadd_ps(a,b,c)
#  define VMSUB(a,b,c)            _mm_fnmadd_ps(a,b,c)
#elif !defined(PFFFT_DISABLE_FMA) && (defined(__aarch64__) || defined(__arm64__))
#  define VMADD(a,b,c)            _mm_fmadd_ps(a,b,c)
#  define VMSUB(a,b,c)            _mm_sub_ps(c, _mm_mul_ps(a,b))
#else
#  define VMADD(a,b,c)            _mm_add_ps(_mm_mul_ps(a,b), c)
#  define VMSUB(a,b,c)            _mm_sub_ps(c, _mm_mul_ps(a,b))
#endif
#define LD_PS1(s)                 _mm_set1_ps(s)
#define VLOAD_UNALIGNED(ptr)      _mm_loadu_ps((const float *)(ptr))
#define VLOAD_ALIGNED(ptr)        _mm_load_ps((const float *)(ptr))
#define VSTORE_UNALIGNED(ptr, v)  _mm_storeu_ps((float*)(ptr), v)
#define VSTORE_ALIGNED(ptr, v)    _mm_store_ps((float*)(ptr), v)
#define INTERLEAVE2(in1, in2, out1, out2) { __m128 tmp__ = _mm_unpacklo_ps(in1, in2); out2 = _mm_unpackhi_ps(in1, in2); out1 = tmp__; }
#define UNINTERLEAVE2(in1, in2, out1, out2) { __m128 tmp__ = _mm_shuffle_ps(in1, in2, _MM_SHUFFLE(2,0,2,0)); out2 = _mm_shuffle_ps(in1, in2, _MM_SHUFFLE(3,1,3,1)); out1 = tmp__; }

#if USE_ALIGNED_ADDRESSES
  #define VLOAD(ptr)              _mm_load_ps((const float *)(ptr))
  #define VSTORE(ptr, v)          _mm_store_ps((float*)(ptr), v)
#else
  #define VLOAD(ptr)              _mm_loadu_ps((const float *)(ptr))
  #define VSTORE(ptr, v)          _mm_storeu_ps((float*)(ptr), v)
#endif


int have_sse_shift_mixer_impl()
{
    return 1;
}

#else

int have_sse_shift_mixer_impl()
{
    return 0;
}

#endif


/*********************************************************************/

/**************/
/*** ALGO A ***/
/**************/

PF_TARGET_CLONES
float shift_math_cc(const complexf *input, complexf* output, int input_size, float rate, float starting_phase)
{
    rate*=2;
    //Shifts the complex spectrum. Basically a complex mixer. This version uses cmath.
    float phase=starting_phase;
    float phase_increment=rate*PI;
    float cosval, sinval;
    for(int i=0;i<input_size; i++)
    {
        cosval=cosf(phase);
        sinval=sinf(phase);
        //we multiply two complex numbers.
        //how? enter this to maxima (software) for explanation:
        //   (a+b*%i)*(c+d*%i), rectform;
        iof(output,i)=cosval*iof(input,i)-sinval*qof(input,i);
        qof(output,i)=sinval*iof(input,i)+cosval*qof(input,i);
        phase+=phase_increment;
        while(phase>2*PI) phase-=2*PI; //@shift_math_cc: normalize phase
        while(phase<0) phase+=2*PI;
    }
    return phase;
}

/*********************************************************************/

/**************/
/*** ALGO B ***/
/**************/

shift_table_data_t shift_table_init(int table_size)
{
    shift_table_data_t output;
    output.table=(float*)malloc(sizeof(float)*table_size);
    output.table_size=table_size;
    for(int i=0;i<table_size;i++)
    {
        output.table[i]=sinf(((float)i/table_size)*(PI/2));
    }
    return output;
}

void shift_table_deinit(shift_table_data_t table_data)
{
    free(table_data.table);
}


PF_TARGET_CLONES
float shift_table_cc(complexf* input, complexf* output, int input_size, float rate, shift_table_data_t table_data, float starting_phase)
{
    rate*=2;
    //Shifts the complex spectrum. Basically a complex mixer. This version uses a pre-built sine table.
    float phase=starting_phase;
    float phase_increment=rate*PI;
    float cosval, sinval;
    for(int i=0;i<input_size; i++) //@shift_math_cc
    {
        int sin_index, cos_index, temp_index, sin_sign, cos_sign;
        int quadrant=(int)(phase/(PI/2.0f)); //between 0 and 3
        float vphase=phase-quadrant*(PI/2.0f);
        sin_index=(int)(vphase/(PI/2.0f))*table_data.table_size;
        cos_index=table_data.table_size-1-sin_index;
        if(quadrant&1) //in quadrant 1 and 3
        {
            temp_index=sin_index;
            sin_index=cos_index;
            cos_index=temp_index;
        }
        sin_sign=(quadrant>1)?-1:1; //in quadrant 2 and 3
        cos_sign=(quadrant&&quadrant<3)?-1:1; //in quadrant 1 and 2
        sinval=sin_sign*table_data.table[sin_index];
        cosval=cos_sign*table_data.table[cos_index];
        //we multiply two complex numbers.
        //how? enter this to maxima (software) for explanation:
        //   (a+b*%i)*(c+d*%i), rectform;
        iof(output,i)=cosval*iof(input,i)-sinval*qof(input,i);
        qof(output,i)=sinval*iof(input,i)+cosval*qof(input,i);
        phase+=phase_increment;
        while(phase>2*PI) phase-=2*PI; //@shift_math_cc: normalize phase
        while(phase<0) phase+=2*PI;
    }
    return phase;
}

/*********************************************************************/

/**************/
/*** ALGO C ***/
/**************/

shift_addfast_data_t shift_addfast_init(float rate)
{
    shift_addfast_data_t output;
    output.phase_increment=2*rate*PI;
    for(int i=0;i<4;i++)
    {
        output.dsin[i]=sinf(output.phase_increment*(i+1));
        output.dcos[i]=cosf(output.phase_increment*(i+1));
    }
    return output;
}

#define SADF_L1(j) \
    cos_vals_ ## j = cos_start * dcos_ ## j - sin_start * dsin_ ## j; \
    sin_vals_ ## j = sin_start * dcos_ ## j + cos_start * dsin_ ## j;
#define SADF_L2(j) \
    iof(output,4*i+j)=(cos_vals_ ## j)*iof(input,4*i+j)-(sin_vals_ ## j)*qof(input,4*i+j); \
    qof(output,4*i+j)=(sin_vals_ ## j)*iof(input,4*i+j)+(cos_vals_ ## j)*qof(input,4*i+j);

PF_TARGET_CLONES
float shift_addfast_cc(complexf *input, complexf* output, int input_size, shift_addfast_data_t* d, float starting_phase)
{
    //input_size should be multiple of 4
    //fprintf(stderr, "shift_addfast_cc: input_size = %d\n", input_size);
    float cos_start=cosf(starting_phase);
    float sin_start=sinf(starting_phase);
    float cos_vals_0, cos_vals_1, cos_vals_2, cos_vals_3,
        sin_vals_0, sin_vals_1, sin_vals_2, sin_vals_3,
        dsin_0 = d->dsin[0], dsin_1 = d->dsin[1], dsin_2 = d->dsin[2], dsin_3 = d->dsin[3],
        dcos_0 = d->dcos[0], dcos_1 = d->dcos[1], dcos_2 = d->dcos[2], dcos_3 = d->dcos[3];

    for(int i=0;i<input_size/4; i++)
    {
        SADF_L1(0)
        SADF_L1(1)
        SADF_L1(2)
        SADF_L1(3)
        SADF_L2(0)
        SADF_L2(1)
        SADF_L2(2)
        SADF_L2(3)
        cos_start = cos_vals_3;
        sin_start = sin_vals_3;
    }
    starting_phase+=input_size*d->phase_increment;
    while(starting_phase>PI) starting_phase-=2*PI;
    while(starting_phase<-PI) starting_phase+=2*PI;
    return starting_phase;
}

#undef SADF_L2


#define SADF_L2(j) \
    tmp_inp_cos = iof(in_out,4*i+j); \
    tmp_inp_sin = qof(in_out,4*i+j); \
    iof(in_out,4*i+j)=(cos_vals_ ## j)*tmp_inp_cos - (sin_vals_ ## j)*tmp_inp_sin; \
    qof(in_out,4*i+j)=(sin_vals_ ## j)*tmp_inp_cos + (cos_vals_ ## j)*tmp_inp_sin;

PF_TARGET_CLONES
float shift_addfast_inp_c(complexf *in_out, int N_cplx, shift_addfast_data_t* d, float starting_phase)
{
    //input_size should be multiple of 4
    //fprintf(stderr, "shift_addfast_cc: input_size = %d\n", input_size);
    float cos_start=cosf(starting_phase);
    float sin_start=sinf(starting_phase);
    float tmp_inp_cos, tmp_inp_sin,
        cos_vals_0, cos_vals_1, cos_vals_2, cos_vals_3,
        sin_vals_0, sin_vals_1, sin_vals_2, sin_vals_3,
        dsin_0 = d->dsin[0], dsin_1 = d->dsin[1], dsin_2 = d->dsin[2], dsin_3 = d->dsin[3],
        dcos_0 = d->dcos[0], dcos_1 = d->dcos[1], dcos_2 = d->dcos[2], dcos_3 = d->dcos[3];

    for(int i=0;i<N_cplx/4; i++)
    {
        SADF_L1(0)
        SADF_L1(1)
        SADF_L1(2)
        SADF_L1(3)
        SADF_L2(0)
        SADF_L2(1)
        SADF_L2(2)
        SADF_L2(3)
        cos_start = cos_vals_3;
        sin_start = sin_vals_3;
    }
    starting_phase+=N_cplx*d->phase_increment;
    while(starting_phase>PI) starting_phase-=2*PI;
    while(starting_phase<-PI) starting_phase+=2*PI;
    return starting_phase;
}

#undef SADF_L1
#undef SADF_L2


/*********************************************************************/

/**************/
/*** ALGO D ***/
/**************/

shift_unroll_data_t shift_unroll_init(float rate, int size)
{
    shift_unroll_data_t output;
    output.phase_increment=2*rate*PI;
    output.size = size;
    output.dsin=(float*)malloc(sizeof(float)*size);
    output.dcos=(float*)malloc(sizeof(float)*size);
    float myphase = 0;
    for(int i=0;i<size;i++)
    {
        myphase += output.phase_increment;
        while(myphase>PI) myphase-=2*PI;
        while(myphase<-PI) myphase+=2*PI;
        output.dsin[i]=sinf(myphase);
        output.dcos[i]=cosf(myphase);
    }
    return output;
}

void shift_unroll_deinit(shift_unroll_data_t* d)
{
    if (!d)
        return;
    free(d->dsin);
    free(d->dcos);
    d->dsin = NULL;
    d->dcos = NULL;
}

static ALWAYS_INLINE(float) shift_unroll_apply(const complexf *input, complexf *output,
                                               int size, const shift_unroll_data_t *d,
                                               float starting_phase) {
  const float cos_start = cosf(starting_phase);
  const float sin_start = sinf(starting_phase);
  assert(size >= 0 && size <= d->size);
  if (size > 0) {
    const float re = input[0].i, im = input[0].q;
    output[0].i = cos_start * re - sin_start * im;
    output[0].q = sin_start * re + cos_start * im;
  }
  /* Table entry i-1 belongs to sample i. Independent phasors allow a
     vector loop with separate real/imaginary lanes on every mixer backend. */
  int i = 1;
#ifdef HAVE_SSE_INTRINSICS
  const v4sf vc = LD_PS1(cos_start), vs = LD_PS1(sin_start);
  for (; i <= size-SIMD_SZ; i += SIMD_SZ) {
    const v4sf tc = VLOAD_UNALIGNED(d->dcos + i-1);
    const v4sf ts = VLOAD_UNALIGNED(d->dsin + i-1);
    const v4sf c = VMSUB(vs, ts, VMUL(vc, tc));
    const v4sf s = VMADD(vs, tc, VMUL(vc, ts));
    const float *p = reinterpret_cast<const float *>(input + i);
    v4sf in_re, in_im, lo, hi;
    UNINTERLEAVE2(VLOAD_UNALIGNED(p), VLOAD_UNALIGNED(p+4), in_re, in_im);
    const v4sf re = VMSUB(in_im, s, VMUL(in_re, c));
    const v4sf im = VMADD(in_re, s, VMUL(in_im, c));
    INTERLEAVE2(re, im, lo, hi);
    float *q = reinterpret_cast<float *>(output + i);
    VSTORE_UNALIGNED(q, lo);
    VSTORE_UNALIGNED(q+4, hi);
  }
#endif
  for (; i < size; ++i) {
    const float c = cos_start * d->dcos[i-1] - sin_start * d->dsin[i-1];
    const float s = sin_start * d->dcos[i-1] + cos_start * d->dsin[i-1];
    const float re = input[i].i, im = input[i].q;
    output[i].i = c * re - s * im;
    output[i].q = s * re + c * im;
  }
  starting_phase += size * d->phase_increment;
  while (starting_phase > PI) starting_phase -= 2*PI;
  while (starting_phase < -PI) starting_phase += 2*PI;
  return starting_phase;
}

PF_TARGET_CLONES
float shift_unroll_cc(complexf *input, complexf *output, int input_size,
                      shift_unroll_data_t *d, float starting_phase) {
  return shift_unroll_apply(input, output, input_size, d, starting_phase);
}

PF_TARGET_CLONES
float shift_unroll_inp_c(complexf *in_out, int size, shift_unroll_data_t *d,
                         float starting_phase) {
  return shift_unroll_apply(in_out, in_out, size, d, starting_phase);
}


/*********************************************************************/

/**************/
/*** ALGO E ***/
/**************/

shift_limited_unroll_data_t shift_limited_unroll_init(float rate)
{
    shift_limited_unroll_data_t output;
    output.phase_increment=2*rate*PI;
    float myphase = 0;
    for(int i=0; i < PF_SHIFT_LIMITED_UNROLL_SIZE; i++)
    {
        myphase += output.phase_increment;
        while(myphase>PI) myphase-=2*PI;
        while(myphase<-PI) myphase+=2*PI;
        output.dcos[i] = cosf(myphase);
        output.dsin[i] = sinf(myphase);
    }
    output.complex_phase.i = 1.0F;
    output.complex_phase.q = 0.0F;
    return output;
}

PF_TARGET_CLONES
void shift_limited_unroll_cc(const complexf *input, complexf* output, int size, shift_limited_unroll_data_t* d)
{
    float cos_start = d->complex_phase.i;
    float sin_start = d->complex_phase.q;
    float cos_val = cos_start, sin_val = sin_start, mag;
    while (size > 0)
    {
        int N = (size >= PF_SHIFT_LIMITED_UNROLL_SIZE) ? PF_SHIFT_LIMITED_UNROLL_SIZE : size;
        for(int i=0;i<N/PF_SHIFT_LIMITED_SIMD_SZ; i++ )
        {
            for(int j=0; j<PF_SHIFT_LIMITED_SIMD_SZ; j++)
            {
                iof(output,PF_SHIFT_LIMITED_SIMD_SZ*i+j) = cos_val*iof(input,PF_SHIFT_LIMITED_SIMD_SZ*i+j) - sin_val*qof(input,PF_SHIFT_LIMITED_SIMD_SZ*i+j);
                qof(output,PF_SHIFT_LIMITED_SIMD_SZ*i+j) = sin_val*iof(input,PF_SHIFT_LIMITED_SIMD_SZ*i+j) + cos_val*qof(input,PF_SHIFT_LIMITED_SIMD_SZ*i+j);
                // calculate complex phasor for next iteration
                cos_val = cos_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] - sin_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
                sin_val = sin_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] + cos_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            }
        }
        // "starts := vals := vals / |vals|"
        mag = sqrtf(cos_val * cos_val + sin_val * sin_val);
        cos_val /= mag;
        sin_val /= mag;
        cos_start = cos_val;
        sin_start = sin_val;

        input += PF_SHIFT_LIMITED_UNROLL_SIZE;
        output += PF_SHIFT_LIMITED_UNROLL_SIZE;
        size -= PF_SHIFT_LIMITED_UNROLL_SIZE;
    }
    d->complex_phase.i = cos_val;
    d->complex_phase.q = sin_val;
}

PF_TARGET_CLONES
void shift_limited_unroll_inp_c(complexf* in_out, int N_cplx, shift_limited_unroll_data_t* d)
{
    float inp_i[PF_SHIFT_LIMITED_SIMD_SZ];
    float inp_q[PF_SHIFT_LIMITED_SIMD_SZ];
    // "vals := starts := phase_state"
    float cos_start = d->complex_phase.i;
    float sin_start = d->complex_phase.q;
    float cos_val = cos_start, sin_val = sin_start, mag;
    while (N_cplx)
    {
        int N = (N_cplx >= PF_SHIFT_LIMITED_UNROLL_SIZE) ? PF_SHIFT_LIMITED_UNROLL_SIZE : N_cplx;
        for(int i=0;i<N/PF_SHIFT_LIMITED_SIMD_SZ; i++ )
        {
            for(int j=0; j<PF_SHIFT_LIMITED_SIMD_SZ; j++)
                inp_i[j] = in_out[PF_SHIFT_LIMITED_SIMD_SZ*i+j].i;
            for(int j=0; j<PF_SHIFT_LIMITED_SIMD_SZ; j++)
                inp_q[j] = in_out[PF_SHIFT_LIMITED_SIMD_SZ*i+j].q;
            for(int j=0; j<PF_SHIFT_LIMITED_SIMD_SZ; j++)
            {
                // "out[] = inp[] * vals"
                iof(in_out,PF_SHIFT_LIMITED_SIMD_SZ*i+j) = cos_val*inp_i[j] - sin_val*inp_q[j];
                qof(in_out,PF_SHIFT_LIMITED_SIMD_SZ*i+j) = sin_val*inp_i[j] + cos_val*inp_q[j];
                // calculate complex phasor for next iteration
                // "vals :=  d[] * starts"
                cos_val = cos_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] - sin_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
                sin_val = sin_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] + cos_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            }
        }
        // "starts := vals := vals / |vals|"
        mag = sqrtf(cos_val * cos_val + sin_val * sin_val);
        cos_val /= mag;
        sin_val /= mag;
        cos_start = cos_val;
        sin_start = sin_val;

        in_out += PF_SHIFT_LIMITED_UNROLL_SIZE;
        N_cplx -= PF_SHIFT_LIMITED_UNROLL_SIZE;
    }
    // "phase_state := starts"
    d->complex_phase.i = cos_start;
    d->complex_phase.q = sin_start;
}


#ifdef HAVE_SSE_INTRINSICS

/*********************************************************************/

/**************/
/*** ALGO F ***/
/**************/

shift_limited_unroll_A_sse_data_t shift_limited_unroll_A_sse_init(float relative_freq, float phase_start_rad)
{
    shift_limited_unroll_A_sse_data_t output;
    float myphase;

    output.phase_increment = 2*relative_freq*PI;

    myphase = 0.0F;
    for (int i = 0; i < PF_SHIFT_LIMITED_UNROLL_SIZE + PF_SHIFT_LIMITED_SIMD_SZ; i += PF_SHIFT_LIMITED_SIMD_SZ)
    {
        for (int k = 0; k < PF_SHIFT_LIMITED_SIMD_SZ; k++)
        {
            myphase += output.phase_increment;
            while(myphase>PI) myphase-=2*PI;
            while(myphase<-PI) myphase+=2*PI;
        }
        output.dcos[i] = cosf(myphase);
        output.dsin[i] = sinf(myphase);
        for (int k = 1; k < PF_SHIFT_LIMITED_SIMD_SZ; k++)
        {
            output.dcos[i+k] = output.dcos[i];
            output.dsin[i+k] = output.dsin[i];
        }
    }

    output.dcos_blk = 0.0F;
    output.dsin_blk = 0.0F;

    myphase = phase_start_rad;
    for (int i = 0; i < PF_SHIFT_LIMITED_SIMD_SZ; i++)
    {
        output.phase_state_i[i] = cosf(myphase);
        output.phase_state_q[i] = sinf(myphase);
        myphase += output.phase_increment;
        while(myphase>PI) myphase-=2*PI;
        while(myphase<-PI) myphase+=2*PI;
    }
    return output;
}


PF_TARGET_CLONES
void shift_limited_unroll_A_sse_inp_c(complexf* in_out, int N_cplx, shift_limited_unroll_A_sse_data_t* d)
{
    // "vals := starts := phase_state"
    __m128 cos_starts = VLOAD( &d->phase_state_i[0] );
    __m128 sin_starts = VLOAD( &d->phase_state_q[0] );
    __m128 cos_vals = cos_starts;
    __m128 sin_vals = sin_starts;
    __m128 inp_re, inp_im;
    __m128 product_re, product_im;
    __m128 interl_prod_a, interl_prod_b;
    __m128 * RESTRICT p_trig_cos_tab;
    __m128 * RESTRICT p_trig_sin_tab;
    __m128 * RESTRICT u = (__m128*)in_out;

    while (N_cplx)
    {
        const int NB = (N_cplx >= PF_SHIFT_LIMITED_UNROLL_SIZE) ? PF_SHIFT_LIMITED_UNROLL_SIZE : N_cplx;
        int B = NB;
        p_trig_cos_tab = (__m128*)( &d->dcos[0] );
        p_trig_sin_tab = (__m128*)( &d->dsin[0] );
        while (B)
        {
            // complex multiplication of 4 complex values from/to in_out[]
            // ==  u[0..3] *= (cos_val[0..3] + i * sin_val[0..3]):
            // "out[] = inp[] * vals"
            UNINTERLEAVE2(VLOAD(u), VLOAD(u+1), inp_re, inp_im);  /* inp_re = all reals; inp_im = all imags */
            product_re = VMSUB( inp_im, sin_vals, VMUL(inp_re, cos_vals) );
            product_im = VMADD( inp_im, cos_vals, VMUL(inp_re, sin_vals) );
            INTERLEAVE2( product_re, product_im, interl_prod_a, interl_prod_b);
            VSTORE(u, interl_prod_a);
            VSTORE(u+1, interl_prod_b);
            u += 2;
            // calculate complex phasor for next iteration
            // cos_val = cos_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] - sin_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // sin_val = sin_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] + cos_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // cos_val[]/sin_val[] .. can't fade towards 0 inside this while loop :-)
            // "vals :=  d[] * starts"
            inp_re = VLOAD(p_trig_cos_tab);
            inp_im = VLOAD(p_trig_sin_tab);
            cos_vals = VMSUB( inp_im, sin_starts, VMUL(inp_re, cos_starts) );
            sin_vals = VMADD( inp_im, cos_starts, VMUL(inp_re, sin_starts) );
            ++p_trig_cos_tab;
            ++p_trig_sin_tab;
            B -= 4;
        }
        N_cplx -= NB;
        /* normalize d->phase_state_i[]/d->phase_state_q[], that magnitude does not fade towards 0 ! */
        /* re-use product_re[]/product_im[] for normalization */
        // "starts := vals := vals / |vals|"
        product_re = VMADD( cos_vals, cos_vals, VMUL(sin_vals, sin_vals) );
#if 0
        // more spikes in spectrum! at PF_SHIFT_LIMITED_UNROLL_SIZE = 64
        // higher spikes in spectrum at PF_SHIFT_LIMITED_UNROLL_SIZE = 16
        product_im = _mm_rsqrt_ps(product_re);
        cos_starts = cos_vals = VMUL(cos_vals, product_im);
        sin_starts = sin_vals = VMUL(sin_vals, product_im);
#else
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 64 - but slower!
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 128 - fast again
        product_im = _mm_sqrt_ps(product_re);
        cos_starts = cos_vals = VDIV(cos_vals, product_im);
        sin_starts = sin_vals = VDIV(sin_vals, product_im);
#endif
    }
    // "phase_state := starts"
    VSTORE( &d->phase_state_i[0], cos_starts );
    VSTORE( &d->phase_state_q[0], sin_starts );
}


/*********************************************************************/

/**************/
/*** ALGO G ***/
/**************/

shift_limited_unroll_B_sse_data_t shift_limited_unroll_B_sse_init(float relative_freq, float phase_start_rad)
{
    shift_limited_unroll_B_sse_data_t output;
    float myphase;

    output.phase_increment = 2*relative_freq*PI;

    myphase = 0.0F;
    for (int i = 0; i < PF_SHIFT_LIMITED_UNROLL_SIZE + PF_SHIFT_LIMITED_SIMD_SZ; i += PF_SHIFT_LIMITED_SIMD_SZ)
    {
        for (int k = 0; k < PF_SHIFT_LIMITED_SIMD_SZ; k++)
        {
            myphase += output.phase_increment;
            while(myphase>PI) myphase-=2*PI;
            while(myphase<-PI) myphase+=2*PI;
        }
        output.dtrig[i+0] = cosf(myphase);
        output.dtrig[i+1] = sinf(myphase);
        output.dtrig[i+2] = output.dtrig[i+0];
        output.dtrig[i+3] = output.dtrig[i+1];
    }

    output.dcos_blk = 0.0F;
    output.dsin_blk = 0.0F;

    myphase = phase_start_rad;
    for (int i = 0; i < PF_SHIFT_LIMITED_SIMD_SZ; i++)
    {
        output.phase_state_i[i] = cosf(myphase);
        output.phase_state_q[i] = sinf(myphase);
        myphase += output.phase_increment;
        while(myphase>PI) myphase-=2*PI;
        while(myphase<-PI) myphase+=2*PI;
    }
    return output;
}


PF_TARGET_CLONES
void shift_limited_unroll_B_sse_inp_c(complexf* in_out, int N_cplx, shift_limited_unroll_B_sse_data_t* d)
{
    // "vals := starts := phase_state"
    __m128 cos_starts = VLOAD( &d->phase_state_i[0] );
    __m128 sin_starts = VLOAD( &d->phase_state_q[0] );
    __m128 cos_vals = cos_starts;
    __m128 sin_vals = sin_starts;
    __m128 inp_re, inp_im;
    __m128 product_re, product_im;
    __m128 interl_prod_a, interl_prod_b;
    __m128 * RESTRICT p_trig_tab;
    __m128 * RESTRICT u = (__m128*)in_out;

    while (N_cplx)
    {
        const int NB = (N_cplx >= PF_SHIFT_LIMITED_UNROLL_SIZE) ? PF_SHIFT_LIMITED_UNROLL_SIZE : N_cplx;
        int B = NB;
        p_trig_tab = (__m128*)( &d->dtrig[0] );
        while (B)
        {
            // complex multiplication of 4 complex values from/to in_out[]
            // ==  u[0..3] *= (cos_val[0..3] + i * sin_val[0..3]):
            // "out[] = inp[] * vals"
            UNINTERLEAVE2(VLOAD(u), VLOAD(u+1), inp_re, inp_im);  /* inp_re = all reals; inp_im = all imags */
            product_re = VMSUB( inp_im, sin_vals, VMUL(inp_re, cos_vals) );
            product_im = VMADD( inp_im, cos_vals, VMUL(inp_re, sin_vals) );
            INTERLEAVE2( product_re, product_im, interl_prod_a, interl_prod_b);
            VSTORE(u, interl_prod_a);
            VSTORE(u+1, interl_prod_b);
            u += 2;
            // calculate complex phasor for next iteration
            // cos_val = cos_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] - sin_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // sin_val = sin_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] + cos_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // cos_val[]/sin_val[] .. can't fade towards 0 inside this while loop :-)
            // "vals :=  d[] * starts"
            product_re = VLOAD(p_trig_tab);
            UNINTERLEAVE2(product_re, product_re, inp_re, inp_im);  /* inp_re = all reals; inp_im = all imags */
            cos_vals = VMSUB( inp_im, sin_starts, VMUL(inp_re, cos_starts) );
            sin_vals = VMADD( inp_im, cos_starts, VMUL(inp_re, sin_starts) );
            ++p_trig_tab;
            B -= 4;
        }
        N_cplx -= NB;
        /* normalize d->phase_state_i[]/d->phase_state_q[], that magnitude does not fade towards 0 ! */
        /* re-use product_re[]/product_im[] for normalization */
        // "starts := vals := vals / |vals|"
        product_re = VMADD( cos_vals, cos_vals, VMUL(sin_vals, sin_vals) );
#if 0
        // more spikes in spectrum! at PF_SHIFT_LIMITED_UNROLL_SIZE = 64
        // higher spikes in spectrum at PF_SHIFT_LIMITED_UNROLL_SIZE = 16
        product_im = _mm_rsqrt_ps(product_re);
        cos_starts = cos_vals = VMUL(cos_vals, product_im);
        sin_starts = sin_vals = VMUL(sin_vals, product_im);
#else
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 64 - but slower!
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 128 - fast again
        product_im = _mm_sqrt_ps(product_re);
        cos_starts = cos_vals = VDIV(cos_vals, product_im);
        sin_starts = sin_vals = VDIV(sin_vals, product_im);
#endif
    }
    // "phase_state := starts"
    VSTORE( &d->phase_state_i[0], cos_starts );
    VSTORE( &d->phase_state_q[0], sin_starts );
}


/*********************************************************************/


/**************/
/*** ALGO H ***/
/**************/

shift_limited_unroll_C_sse_data_t shift_limited_unroll_C_sse_init(float relative_freq, float phase_start_rad)
{
    shift_limited_unroll_C_sse_data_t output;
    float myphase;

    output.phase_increment = 2*relative_freq*PI;

    myphase = 0.0F;
    for (int i = 0; i < PF_SHIFT_LIMITED_UNROLL_SIZE + PF_SHIFT_LIMITED_SIMD_SZ; i += PF_SHIFT_LIMITED_SIMD_SZ)
    {
        for (int k = 0; k < PF_SHIFT_LIMITED_SIMD_SZ; k++)
        {
            myphase += output.phase_increment;
            while(myphase>PI) myphase-=2*PI;
            while(myphase<-PI) myphase+=2*PI;
        }
        output.dinterl_trig[2*i] = cosf(myphase);
        output.dinterl_trig[2*i+4] = sinf(myphase);
        for (int k = 1; k < PF_SHIFT_LIMITED_SIMD_SZ; k++)
        {
            output.dinterl_trig[2*i+k] = output.dinterl_trig[2*i];
            output.dinterl_trig[2*i+k+4] = output.dinterl_trig[2*i+4];
        }
    }

    output.dcos_blk = 0.0F;
    output.dsin_blk = 0.0F;

    myphase = phase_start_rad;
    for (int i = 0; i < PF_SHIFT_LIMITED_SIMD_SZ; i++)
    {
        output.phase_state_i[i] = cosf(myphase);
        output.phase_state_q[i] = sinf(myphase);
        myphase += output.phase_increment;
        while(myphase>PI) myphase-=2*PI;
        while(myphase<-PI) myphase+=2*PI;
    }
    return output;
}


PF_TARGET_CLONES
void shift_limited_unroll_C_sse_inp_c(complexf* in_out, int N_cplx, shift_limited_unroll_C_sse_data_t* d)
{
    // "vals := starts := phase_state"
    __m128 cos_starts = VLOAD( &d->phase_state_i[0] );
    __m128 sin_starts = VLOAD( &d->phase_state_q[0] );
    __m128 cos_vals = cos_starts;
    __m128 sin_vals = sin_starts;
    __m128 inp_re, inp_im;
    __m128 product_re, product_im;
    __m128 interl_prod_a, interl_prod_b;
    __m128 * RESTRICT p_trig_tab;
    __m128 * RESTRICT u = (__m128*)in_out;

    while (N_cplx)
    {
        const int NB = (N_cplx >= PF_SHIFT_LIMITED_UNROLL_SIZE) ? PF_SHIFT_LIMITED_UNROLL_SIZE : N_cplx;
        int B = NB;
        p_trig_tab = (__m128*)( &d->dinterl_trig[0] );
        while (B)
        {
            // complex multiplication of 4 complex values from/to in_out[]
            // ==  u[0..3] *= (cos_val[0..3] + i * sin_val[0..3]):
            // "out[] = inp[] * vals"
            UNINTERLEAVE2(VLOAD(u), VLOAD(u+1), inp_re, inp_im);  /* inp_re = all reals; inp_im = all imags */
            product_re = VMSUB( inp_im, sin_vals, VMUL(inp_re, cos_vals) );
            product_im = VMADD( inp_im, cos_vals, VMUL(inp_re, sin_vals) );
            INTERLEAVE2( product_re, product_im, interl_prod_a, interl_prod_b);
            VSTORE(u, interl_prod_a);
            VSTORE(u+1, interl_prod_b);
            u += 2;
            // calculate complex phasor for next iteration
            // cos_val = cos_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] - sin_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // sin_val = sin_start * d->dcos[PF_SHIFT_LIMITED_SIMD_SZ*i+j] + cos_start * d->dsin[PF_SHIFT_LIMITED_SIMD_SZ*i+j];
            // cos_val[]/sin_val[] .. can't fade towards 0 inside this while loop :-)
            // "vals :=  d[] * starts"
            inp_re = VLOAD(p_trig_tab);
            inp_im = VLOAD(p_trig_tab+1);
            cos_vals = VMSUB( inp_im, sin_starts, VMUL(inp_re, cos_starts) );
            sin_vals = VMADD( inp_im, cos_starts, VMUL(inp_re, sin_starts) );
            p_trig_tab += 2;
            B -= 4;
        }
        N_cplx -= NB;
        /* normalize d->phase_state_i[]/d->phase_state_q[], that magnitude does not fade towards 0 ! */
        /* re-use product_re[]/product_im[] for normalization */
        // "starts := vals := vals / |vals|"
        product_re = VMADD( cos_vals, cos_vals, VMUL(sin_vals, sin_vals) );
#if 0
        // more spikes in spectrum! at PF_SHIFT_LIMITED_UNROLL_SIZE = 64
        // higher spikes in spectrum at PF_SHIFT_LIMITED_UNROLL_SIZE = 16
        product_im = _mm_rsqrt_ps(product_re);
        cos_starts = cos_vals = VMUL(cos_vals, product_im);
        sin_starts = sin_vals = VMUL(sin_vals, product_im);
#else
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 64 - but slower!
        // spectrally comparable to shift_match_cc() with PF_SHIFT_LIMITED_UNROLL_SIZE = 128 - fast again
        product_im = _mm_sqrt_ps(product_re);
        cos_starts = cos_vals = VDIV(cos_vals, product_im);
        sin_starts = sin_vals = VDIV(sin_vals, product_im);
#endif
    }
    // "phase_state := starts"
    VSTORE( &d->phase_state_i[0], cos_starts );
    VSTORE( &d->phase_state_q[0], sin_starts );
}


#else

/*********************************************************************/

shift_limited_unroll_A_sse_data_t shift_limited_unroll_A_sse_init(float, float) {
    assert(0);
    return shift_limited_unroll_A_sse_data_t();
}
shift_limited_unroll_B_sse_data_t shift_limited_unroll_B_sse_init(float, float) {
    assert(0);
    return shift_limited_unroll_B_sse_data_t();
}
shift_limited_unroll_C_sse_data_t shift_limited_unroll_C_sse_init(float, float) {
    assert(0);
    return shift_limited_unroll_C_sse_data_t();
}

void shift_limited_unroll_A_sse_inp_c(complexf*, int, shift_limited_unroll_A_sse_data_t*) {
    assert(0);
}
void shift_limited_unroll_B_sse_inp_c(complexf*, int, shift_limited_unroll_B_sse_data_t*) {
    assert(0);
}
void shift_limited_unroll_C_sse_inp_c(complexf*, int, shift_limited_unroll_C_sse_data_t*) {
    assert(0);
}

#endif


/*********************************************************************/

/**************/
/*** ALGO I ***/
/**************/

/* Rebuild the lanes from the next sample's phase. Direct double-precision
   rotations avoid the single-step tangent singularity at odd multiples of pi.
   Reducing rate before multiplying also keeps large finite rates bounded. */
static void recursive_osc_update(float rate, int lanes, float *u_cos, float *v_sin,
                                 float *k1, float *k2) {
  const double pi = 3.14159265358979323846;
  const double step = fmod(static_cast<double>(rate), 2.0) * pi;
  const double u = u_cos[0], v = v_sin[0];
  for (int j = 1; j < lanes; ++j) {
    const double c = cos(j * step), s = sin(j * step);
    u_cos[j] = static_cast<float>(u * c - v * s);
    v_sin[j] = static_cast<float>(v * c + u * s);
  }
  const double block_step = fmod(static_cast<double>(rate) * lanes, 2.0) * pi;
  *k1 = static_cast<float>(tan(0.5 * block_step));
  *k2 = static_cast<float>(sin(block_step));
}

/* For |k1| > 1, rotate by theta +/- pi, then negate both components:
     tan((theta +/- pi)/2) = -1/k1, sin(theta +/- pi) = -k2.
   This bounds the three-shear recurrence's intermediate values even at the
   old singular rates (e.g. rate=1/8 for eight lanes). The public coefficient
   and state layouts stay unchanged. Negate and Mix are compile-time choices. */
template<int Lanes, bool Mix, bool Negate>
static void recursive_osc_apply(const complexf *input, complexf *output, int size,
                                float k1, float k2, float *u_cos, float *v_sin) {
  assert(size >= 0 && size % Lanes == 0);
  /* As in the original eight-lane loop, never overrun a partial final block
     when assertions are disabled. Callers must still supply whole blocks. */
  size = size / Lanes * Lanes;
  if (Negate) {
    k1 = -1.0f / k1;
    k2 = -k2;
  }
#ifdef HAVE_SSE_INTRINSICS
  const v4sf vk1 = LD_PS1(k1), vk2 = LD_PS1(k2);
  v4sf u[Lanes / SIMD_SZ], v[Lanes / SIMD_SZ];
  for (int j = 0; j < Lanes / SIMD_SZ; ++j) {
    u[j] = VLOAD_UNALIGNED(u_cos + SIMD_SZ*j);
    v[j] = VLOAD_UNALIGNED(v_sin + SIMD_SZ*j);
  }
  for (int i = 0; i < size; i += Lanes) {
    for (int j = 0; j < Lanes / SIMD_SZ; ++j) {
      v4sf re = u[j], im = v[j], lo, hi;
      if (Mix) {
        const float *p = reinterpret_cast<const float *>(input + i + SIMD_SZ*j);
        v4sf in_re, in_im;
        UNINTERLEAVE2(VLOAD_UNALIGNED(p), VLOAD_UNALIGNED(p+4), in_re, in_im);
        re = VMSUB(in_im, v[j], VMUL(in_re, u[j]));
        im = VMADD(in_im, u[j], VMUL(in_re, v[j]));
      }
      float *p = reinterpret_cast<float *>(output + i + SIMD_SZ*j);
      INTERLEAVE2(re, im, lo, hi);
      VSTORE_UNALIGNED(p, lo);
      VSTORE_UNALIGNED(p+4, hi);
      const v4sf tmp = VMSUB(vk1, v[j], u[j]);
      v[j] = VMADD(vk2, tmp, v[j]);
      u[j] = VMSUB(vk1, v[j], tmp);
      if (Negate) {
        u[j] = VSUB(LD_PS1(0), u[j]);
        v[j] = VSUB(LD_PS1(0), v[j]);
      }
    }
  }
  for (int j = 0; j < Lanes / SIMD_SZ; ++j) {
    VSTORE_UNALIGNED(u_cos + SIMD_SZ*j, u[j]);
    VSTORE_UNALIGNED(v_sin + SIMD_SZ*j, v[j]);
  }
#else
  for (int i = 0; i < size; i += Lanes) {
    for (int j = 0; j < Lanes; ++j) {
      const float u = u_cos[j], v = v_sin[j];
      if (Mix) {
        const complexf in = input[i+j];
        output[i+j].i = u * in.i - v * in.q;
        output[i+j].q = v * in.i + u * in.q;
      } else {
        output[i+j].i = u;
        output[i+j].q = v;
      }
      const float tmp = u - k1 * v;
      const float next_v = v + k2 * tmp;
      const float next_u = tmp - k1 * next_v;
      u_cos[j] = Negate ? -next_u : next_u;
      v_sin[j] = Negate ? -next_v : next_v;
    }
  }
#endif
}

template<int Lanes, bool Mix>
static void recursive_osc_dispatch(const complexf *input, complexf *output, int size,
                                   float k1, float k2, float *u_cos, float *v_sin) {
  if (fabsf(k1) > 1.0f)
    recursive_osc_apply<Lanes, Mix, true>(input, output, size, k1, k2, u_cos, v_sin);
  else
    recursive_osc_apply<Lanes, Mix, false>(input, output, size, k1, k2, u_cos, v_sin);
}

void shift_recursive_osc_update_rate(float rate, shift_recursive_osc_conf_t *conf,
                                     shift_recursive_osc_t *state) {
  recursive_osc_update(rate, PF_SHIFT_RECURSIVE_SIMD_SZ, state->u_cos, state->v_sin,
                       &conf->k1, &conf->k2);
}

void shift_recursive_osc_init(float rate, float starting_phase,
                              shift_recursive_osc_conf_t *conf, shift_recursive_osc_t *state) {
  state->u_cos[0] = cosf(starting_phase);
  state->v_sin[0] = sinf(starting_phase);
  shift_recursive_osc_update_rate(rate, conf, state);
}

PF_TARGET_CLONES
void shift_recursive_osc_cc(const complexf *input, complexf *output, int size,
                            const shift_recursive_osc_conf_t *conf, shift_recursive_osc_t *state) {
  recursive_osc_dispatch<PF_SHIFT_RECURSIVE_SIMD_SZ, true>(
      input, output, size, conf->k1, conf->k2, state->u_cos, state->v_sin);
}

PF_TARGET_CLONES
void shift_recursive_osc_inp_c(complexf *in_out, int size,
                               const shift_recursive_osc_conf_t *conf, shift_recursive_osc_t *state) {
  recursive_osc_dispatch<PF_SHIFT_RECURSIVE_SIMD_SZ, true>(
      in_out, in_out, size, conf->k1, conf->k2, state->u_cos, state->v_sin);
}

PF_TARGET_CLONES
void gen_recursive_osc_c(complexf *output, int size,
                          const shift_recursive_osc_conf_t *conf, shift_recursive_osc_t *state) {
  recursive_osc_dispatch<PF_SHIFT_RECURSIVE_SIMD_SZ, false>(
      NULL, output, size, conf->k1, conf->k2, state->u_cos, state->v_sin);
}

#ifdef HAVE_SSE_INTRINSICS

/*********************************************************************/

/**************/
/*** ALGO J ***/
/**************/

void shift_recursive_osc_sse_update_rate(float rate, shift_recursive_osc_sse_conf_t *conf,
                                         shift_recursive_osc_sse_t *state) {
  recursive_osc_update(rate, PF_SHIFT_RECURSIVE_SIMD_SSE_SZ, state->u_cos, state->v_sin,
                       &conf->k1, &conf->k2);
}

void shift_recursive_osc_sse_init(float rate, float starting_phase,
                                  shift_recursive_osc_sse_conf_t *conf,
                                  shift_recursive_osc_sse_t *state) {
  state->u_cos[0] = cosf(starting_phase);
  state->v_sin[0] = sinf(starting_phase);
  shift_recursive_osc_sse_update_rate(rate, conf, state);
}

PF_TARGET_CLONES
void shift_recursive_osc_sse_inp_c(complexf *in_out, int size,
                                   const shift_recursive_osc_sse_conf_t *conf,
                                   shift_recursive_osc_sse_t *state) {
  recursive_osc_dispatch<PF_SHIFT_RECURSIVE_SIMD_SSE_SZ, true>(
      in_out, in_out, size, conf->k1, conf->k2, state->u_cos, state->v_sin);
}

#else

void shift_recursive_osc_sse_update_rate(float, shift_recursive_osc_sse_conf_t *, shift_recursive_osc_sse_t *)
{
    assert(0);
}

void shift_recursive_osc_sse_init(float, float, shift_recursive_osc_sse_conf_t *, shift_recursive_osc_sse_t *)
{
    assert(0);
}


void shift_recursive_osc_sse_inp_c(complexf*,
    int, const shift_recursive_osc_sse_conf_t *, shift_recursive_osc_sse_t*)
{
    assert(0);
}

#endif

