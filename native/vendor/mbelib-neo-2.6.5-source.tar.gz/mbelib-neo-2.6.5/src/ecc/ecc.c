// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 *
 * Copyright (C) 2010 mbelib Author
 * GPG Key ID: 0xEA5EFE2C (9E7A 5527 9CDC EBF7 BF1B  D772 4F98 E863 EA5E FE2C)
 *
 * Portions were originally under the ISC license; this mbelib-neo
 * distribution is provided under GPL-2.0-or-later. See LICENSE for details.
 */

/**
 * @file
 * @brief Error-correcting code helpers for Golay and Hamming.
 */

#include <stdint.h>
#include <string.h>
#include "ecc_const.h"
#include "mbe_ecc.h"
#include "mbe_result.h"
#include "mbelib-neo/mbelib.h"

/*
 * Precomputed correction masks for Hamming (15,11) variants.
 * These map 4-bit syndromes to a single-bit mask (1 << bit_index) and
 * avoid any runtime initialization or data races.
 */
static const int ham1511_lut[16] = {
    /* index: syndrome [0..15] */
    0, 8, 4, 2048, 2, 512, 64, 8192, 1, 256, 32, 4096, 16, 1024, 128, 16384,
};

static const int ham1511_7100_lut[16] = {
    /* index: syndrome [0..15] */
    0, 8, 4, 64, 2, 512, 32, 2048, 1, 16384, 256, 8192, 16, 128, 1024, 4096,
};

static void
golay_encode_data_word(uint32_t data, char candidate[23]) {
    uint32_t ecc = 0u;

    for (int i = 0; i < 12; ++i) {
        int bit = (int)((data >> (11 - i)) & 1u);
        candidate[22 - i] = (char)bit;
        if (bit != 0) {
            ecc ^= (uint32_t)golayGenerator[i];
        }
    }
    for (int j = 10; j >= 0; --j) {
        candidate[j] = (char)((ecc >> j) & 1u);
    }
}

void
mbe_golay2312_encode(const char in12[12], char out23[23]) {
    uint32_t data = 0u;

    for (int i = 0; i < 12; ++i) {
        data = (data << 1) | (uint32_t)(in12[i] & 1);
    }
    golay_encode_data_word(data, out23);
}

static uint32_t
hamming_block_from_bits(const char code[15]) {
    uint32_t block = 0u;

    for (int i = 14; i >= 0; i--) {
        block <<= 1;
        block |= (uint32_t)(code[i] & 1);
    }
    return block;
}

/* Even parity of the bits set in v. */
static int
bit_parity(uint32_t v) {
    v ^= v >> 8;
    v ^= v >> 4;
    v ^= v >> 2;
    v ^= v >> 1;
    return (int)(v & 1u);
}

void
mbe_hamming1511_encode(const char in11[11], char out15[15]) {
    /* mbe_hamming1511() returns the data at positions 14..4, most significant
     * first. Generator row r checks data bits and exactly one parity
     * position, 3 - r (its low nibble is 8, 4, 2, 1), so each parity bit is the
     * parity of its row's data bits. */
    memset(out15, 0, 15);
    for (int i = 0; i < 11; ++i) {
        out15[14 - i] = (char)(in11[i] & 1);
    }
    const uint32_t data = hamming_block_from_bits(out15);
    for (int r = 0; r < 4; ++r) {
        out15[3 - r] = (char)bit_parity(data & (uint32_t)hammingGenerator[r] & 0x7FF0u);
    }
}

/**
 * @brief Correct a (23,12) Golay encoded block in-place and extract data.
 * @param block Pointer to packed 23-bit codeword (LSBs contain codeword). On return, holds 12-bit data.
 */
int
mbe_checkGolayBlock(long int* block) {

    int i;
    int syndrome, eccexpected, eccbits, databits;
    uint32_t mask;
    uint32_t block_u;

    if (!block) {
        return MBE_STATUS_INVALID_ARGUMENT;
    }

    block_u = (uint32_t)(*block);

    mask = 0x400000u; /* MSB of 23-bit codeword */
    eccexpected = 0;
    for (i = 0; i < 12; i++) {
        if ((block_u & mask) != 0u) {
            eccexpected ^= golayGenerator[i];
        }
        mask >>= 1;
    }
    eccbits = (int)(block_u & 0x7ffu);
    syndrome = eccexpected ^ eccbits;

    databits = (int)(block_u >> 11);
    databits ^= golayMatrix[syndrome];

    *block = (long)databits;
    return 0;
}

/**
 * @brief Decode a (23,12) Golay codeword.
 * @param in  Input bits, LSB at index 0, length 23.
 * @param out Output bits, corrected, LSB at index 0, length 23.
 * @return Number of corrected bit errors in the protected portion.
 */
int
mbe_golay2312(const char* in, char* out) {

    int i, errs;
    uint32_t block = 0u;
    int ret;

    if (!out) {
        return MBE_STATUS_INVALID_ARGUMENT;
    }
    ret = mbe_validate_bits(in, 23u);
    if (ret < 0) {
        return ret;
    }

    for (i = 22; i >= 0; i--) {
        block <<= 1;
        block |= (uint32_t)(in[i] & 1);
    }

    long tmp = (long)block;
    ret = mbe_checkGolayBlock(&tmp);
    if (ret < 0) {
        return ret;
    }
    block = (uint32_t)tmp;

    for (i = 22; i >= 11; i--) {
        out[i] = (char)((block & 2048u) >> 11);
        block <<= 1;
    }
    for (i = 10; i >= 0; i--) {
        out[i] = in[i];
    }

    errs = 0;
    for (i = 22; i >= 11; i--) {
        if (out[i] != in[i]) {
            errs++;
        }
    }
    return errs;
}

/**
 * @brief Decode a (15,11) Hamming codeword.
 * @param in  Input bits, LSB at index 0, length 15.
 * @param out Output bits, corrected, LSB at index 0, length 15.
 * @return Number of corrected bit errors (0 or 1).
 * @note Uses a precomputed syndrome→bitmask LUT for thread safety (no lazy init).
 */
int
mbe_hamming1511(const char* in, char* out) {
    int i, j, errs;
    uint32_t block = 0u;
    int syndrome;
    int ret;

    if (!out) {
        return MBE_STATUS_INVALID_ARGUMENT;
    }
    ret = mbe_validate_bits(in, 15u);
    if (ret < 0) {
        return ret;
    }

    errs = 0;

    for (i = 14; i >= 0; i--) {
        block <<= 1;
        block |= (uint32_t)(in[i] & 1);
    }

    syndrome = 0;
    for (i = 0; i < 4; i++) {
        int stmp = (int)(block & (uint32_t)hammingGenerator[i]);
        int stmp2 = (stmp & 1);
        for (j = 0; j < 14; j++) {
            stmp >>= 1;
            stmp2 ^= (stmp & 1);
        }
        syndrome |= (stmp2 << i);
    }
    if (syndrome > 0) {
        errs++;
        block ^= (uint32_t)ham1511_lut[syndrome];
    }

    for (i = 14; i >= 0; i--) {
        out[i] = (char)((block & 0x4000u) >> 14);
        block <<= 1;
    }
    return errs;
}

/**
 * @brief Decode a (15,11) Hamming codeword with IMBE 7100x4400 mapping.
 * @param in  Input bits, LSB at index 0, length 15.
 * @param out Output bits, corrected, LSB at index 0, length 15.
 * @return Number of corrected bit errors (0 or 1).
 * @note Uses a precomputed syndrome→bitmask LUT for thread safety (no lazy init).
 */
int
mbe_7100x4400hamming1511(const char* in, char* out) {
    int i, j, errs;
    uint32_t block = 0u;
    int syndrome;
    int ret;

    if (!out) {
        return MBE_STATUS_INVALID_ARGUMENT;
    }
    ret = mbe_validate_bits(in, 15u);
    if (ret < 0) {
        return ret;
    }

    errs = 0;

    for (i = 14; i >= 0; i--) {
        block <<= 1;
        block |= (uint32_t)(in[i] & 1);
    }

    syndrome = 0;
    for (i = 0; i < 4; i++) {
        int stmp = (int)(block & (uint32_t)imbe7100x4400hammingGenerator[i]);
        int stmp2 = (stmp & 1);
        for (j = 0; j < 14; j++) {
            stmp >>= 1;
            stmp2 ^= (stmp & 1);
        }
        syndrome |= (stmp2 << i);
    }
    if (syndrome > 0) {
        errs++;
        block ^= (uint32_t)ham1511_7100_lut[syndrome];
    }

    for (i = 14; i >= 0; i--) {
        out[i] = (char)((block & 0x4000u) >> 14);
        block <<= 1;
    }
    return errs;
}
