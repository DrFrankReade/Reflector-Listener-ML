<!-- SPDX-License-Identifier: GPL-2.0-or-later -->
# mbelib-neo

Performance‑enhanced IMBE/AMBE vocoder primitives and a TETRA ACELP speech decoder, with a modern CMake build, installable headers, and pkg-config/CMake package integration.

Project homepage: https://github.com/arancormonk/mbelib-neo

[![CI](https://github.com/arancormonk/mbelib-neo/actions/workflows/ci.yml/badge.svg)](https://github.com/arancormonk/mbelib-neo/actions/workflows/ci.yml)
[![OpenSSF Best Practices](https://www.bestpractices.dev/projects/12975/badge)](https://www.bestpractices.dev/projects/12975)
[![OpenSSF Baseline](https://www.bestpractices.dev/projects/12975/baseline)](https://www.bestpractices.dev/projects/12975)

## Patent Notice

Use and distribution of the vocoders may implicate patents. The project has
not established third-party patent clearance; educational or research use is
not asserted as an exemption. AMBE+2 and TETRA remain enabled with the open
questions recorded in [the dated patent review](legal/patents.md).

## License

The project's contributions are GPL-2.0-or-later; original ISC mbelib notices
and PFFFT's exact license texts are retained. The source-only OP25 quality patch
is GPL-3.0-or-later. TETRA codebook data retains its ETSI attribution, while
redistribution permission and GPL compatibility remain unresolved. No blanket
license conclusion is asserted for the combined distribution.

Read the [component inventory](legal/component-table.md) and
[licensing status and retained-component exception](legal/status.md). Starting
with 2.6.0, releases include a **complete corresponding-source archive** with
the pinned PFFFT source, build inputs, tests and notices alongside the binaries.
See [offline source builds](docs/source-build.md) and
[release verification](docs/release-verification.md).

## Overview

- A performance‑enhanced fork of [lwvmobile/mbelib](https://github.com/lwvmobile/mbelib), which is a fork of [szechyjs/mbelib](https://github.com/szechyjs/mbelib)
- Supports IMBE 7200x4400 (P25 Phase 1), IMBE 7100x4400 (ProVoice), AMBE (D‑STAR), and AMBE+2 (DMR, NXDN, P25 Phase 2, dPMR, etc.).
- Decodes TETRA full-rate speech (ETSI EN 300 395-2 ACELP, 137 bits per 30 ms frame) with bad-frame concealment. The decoder is integer fixed-point and passes the EN 300 395-4 decoder test bit for bit (see [TETRA decoding](#tetra-decoding)).
- Public API in `#include <mbelib-neo/mbelib.h>` with version macro `MBELIB_VERSION`.
- v2.0.0 is an ABI-breaking release that adds strict bit-array validation, soft-decision ECC/frame decode, staged frame-decode helpers, and result-structured synthesis APIs; use older tags for the v1 API.
- Ships as shared and static libraries: `libmbe-neo.{so|dylib}` on Unix-like platforms, and `mbe-neo.dll` + import lib / `mbe-neo-static.lib` on Windows.
- Installable CMake package (`mbe_neo::mbe_shared` / `mbe_neo::mbe_static`) and pkg-config file (`libmbe-neo`).

## Build From Source

Requirements

- C compiler with C99 support.
- CMake ≥ 3.20.
- On non‑Windows platforms, links against `-lm` automatically.
- The first configure downloads a fixed PFFFT fork revision and verifies its SHA-256. No submodule or C++ compiler is needed.

Release source bundles automatically use their hash-verified PFFFT archive.
For a fresh offline build from a Git checkout, supply an extracted copy of the pinned
fork (see [dependency updates](docs/dependencies.md)):

```sh
cmake --preset dev-debug -DFETCHCONTENT_SOURCE_DIR_MBELIB_PFFFT=/absolute/path/to/pffft
```

An already populated build directory can be reconfigured offline with
`-DFETCHCONTENT_FULLY_DISCONNECTED=ON`. PFFFT is compiled into both libraries;
consumers need no separate PFFFT library.

Using CMake presets (recommended)

```
# From the repository root:

# Debug build with tests/examples
cmake --preset dev-debug
cmake --build --preset dev-debug -j
ctest --preset dev-debug -V

# Release build (SIMD + fast-math + LTO)
cmake --preset dev-release
cmake --build --preset dev-release -j

# Optional sanitizers (Linux/Clang/GCC)
cmake --preset asan-ubsan-debug
cmake --build --preset asan-ubsan-debug -j
ctest --preset asan-ubsan-debug -V

# Disable tone synthesis (AMBE tones)
cmake --preset notones-debug
cmake --build --preset notones-debug -j
ctest --preset notones-debug -V
```

Notes

- Presets create out-of-source builds under `build/<preset>/`. Run the above from the repo root.
- Alternatively, you can run from anywhere using `cmake -S <repo> -B <builddir>`.

Manual configure/build

```
# From the repository root (single-config generators like Ninja/Make):
cmake -S . -B build/manual-debug -DCMAKE_BUILD_TYPE=Debug -DMBELIB_BUILD_TESTS=ON -DMBELIB_BUILD_EXAMPLES=ON
cmake --build build/manual-debug -j
ctest --test-dir build/manual-debug -V

# From anywhere (equivalent):
cmake -S <repo-path> -B <build-dir> -DCMAKE_BUILD_TYPE=Debug -DMBELIB_BUILD_TESTS=ON -DMBELIB_BUILD_EXAMPLES=ON
cmake --build <build-dir> -j
ctest --test-dir <build-dir> -V
```

## Install / Uninstall

```
# Single-config generators (Unix Makefiles/Ninja):
cmake --install build/dev-release

# Multi-config generators (Visual Studio/Xcode):
cmake --install build/dev-release --config Release

# Uninstall from the same build directory
cmake --build build/dev-release --target uninstall
```

## Tagged Releases

GitHub Actions builds release package artifacts when you push a tag matching `vX.Y.Z`.
The tag must match the project version declared in `CMakeLists.txt` and verify as an annotated tag signed by one of the trusted release keys, or the release workflow fails before packaging.

On a matching tag, CI rebuilds `dev-release`, reruns the release preset tests, packages the installed library tree for Linux, macOS, and Windows, generates SPDX SBOMs, creates GitHub artifact attestations, and creates or overwrites the matching GitHub Release assets.
Release verification instructions are in `docs/release-verification.md`.

Typical release flow:

```
# Update project(mbelib-neo VERSION X.Y.Z ...) first, commit, and push.

git tag -s vX.Y.Z -m "mbelib-neo X.Y.Z"
git push origin vX.Y.Z
```

## Configuration Options

- `-DNOTONES=ON` — Disable AMBE/AMBE+2 tone synthesis (adds `-DDISABLE_AMBE_TONES`).
- `-DMBELIB_BUILD_TESTS=ON` — Build CTest executables (default ON).
- `-DMBELIB_BUILD_EXAMPLES=ON` — Build `examples/` (default ON).
- `-DMBELIB_ENABLE_WARNINGS=ON` — Enable common warnings (default ON).
- `-DMBELIB_WARNINGS_AS_ERRORS=ON` — Treat warnings as errors (default ON).
- `-DMBELIB_ENABLE_ASAN=ON` — Enable AddressSanitizer in the Debug configuration.
- `-DMBELIB_ENABLE_UBSAN=ON` — Enable UndefinedBehaviorSanitizer in the Debug configuration.
- `-DMBE_ENABLE_DEBUG_LOGS=ON` — Verbose debug logging in codec sources.
- `-DMBELIB_BUILD_DOCS=ON` — Add `docs` target (requires Doxygen).
- `-DMBELIB_ENABLE_FAST_MATH=ON` — Enable fast-math (`-ffast-math`/`/fp:fast`) on library targets.
  PCM conversion is always compiled with IEEE semantics so NaN/Inf handling is preserved.
- `-DMBELIB_ENABLE_LTO=ON` — Enable IPO/LTO for the Release and RelWithDebInfo configurations when supported (single- and multi-config generators).
- `-DMBELIB_ENABLE_HARDENING=ON` — Enable supported Release-like compiler/linker hardening (default ON).
- `-DMBELIB_ENABLE_SIMD=ON` — Enable SSE2/AVX2/NEON routines when the compiler target provides them, otherwise use scalar routines. Defaults to ON for Release, RelWithDebInfo, and MinSizeRel builds of 64-bit targets (and for multi-config generators without a build type), and OFF otherwise. On baseline x86-64 the width-dependent kernels also get an AVX2/FMA copy that is chosen at run time on CPUs with AVX2. The bundled FFT also falls back to scalar when its compiler target has no supported SIMD backend. On 32-bit ARM, pass `-DCMAKE_C_FLAGS=-mfpu=neon` to enable NEON; the option itself preserves the toolchain's FPU selection. Measure performance on your own core. On 32-bit x86, this option compiles the library for SSE2 and therefore requires an SSE2-capable CPU; leave it OFF for baseline i386 portability. See [SIMD target selection](docs/build-installation.md#simd-target-selection).
- `-DMBELIB_ENABLE_NATIVE=ON` — Tune the libraries' release-like configurations for the build host's CPU (`-march=native`/`-mcpu=native`, or a probed `/arch:` level for MSVC and clang-cl) when that is safe: not when cross-compiling or `CMAKE_C_COMPILER_TARGET` is set, for Android/iOS/Emscripten, for foreign or several `CMAKE_OSX_ARCHITECTURES`, or when the compiler command, `CMAKE_C_FLAGS` or MSVC's `CL`/`_CL_` already select a target ISA (default ON). Debug is never tuned, and the flags never reach the exported targets or pkg-config. **Pass `-DMBELIB_ENABLE_NATIVE=OFF` to build portable binaries for distribution.** See [host tuning](docs/build-installation.md#host-tuning-mbelib_enable_native).
- `-DMBELIB_TEST_REQUIRE_AVX2=ON` — Fail, rather than skip, `test_golden_pcm_avx2` when the build or CPU cannot run the AVX2 kernels (for CI on AVX2 runners).
- Note: the `dev-release` preset enables SIMD, fast-math, and LTO by default when supported, and keeps the native default, so its binaries are tuned for the build host.
- `-DMBELIB_BUILD_BENCHMARKS=ON` — Build optional local micro‑benchmarks (not run in CI): `bench_synth`, `bench_unvoiced`, `bench_convert`, and `bench_encode` (D-STAR, AMBE+2 and IMBE encoders).
- `-DMBELIB_BUILD_TOOLS=ON` — Build the opt-in `mbe_quality_eval` public-API decoder and spectral analyzer, and the `mbe_tetra_decode` TETRA conformance-file decoder. See the [quality evaluation workflow](docs/testing.md#speech-quality-evaluation) and [TETRA conformance](docs/testing.md#tetra-conformance).

## Using The Library

Headers and linking

- Public header: `#include <mbelib-neo/mbelib.h>`
- pkg-config: `pkg-config --cflags --libs libmbe-neo`
- CMake package:
  ```cmake
  find_package(mbe-neo CONFIG REQUIRED)
  target_link_libraries(your_target PRIVATE mbe_neo::mbe_shared) # or mbe_neo::mbe_static
  ```

Minimal example

```c
#include <stdio.h>
#include <mbelib-neo/mbelib.h>

int main(void) {
  printf("mbelib version: %s\n", mbe_versionString());
  return 0;
}
```

You can also build and run the bundled example:

```
cmake --build build/dev-debug --target example_print_version
./build/dev-debug/example_print_version
```

### Frame/Data API Quick Reference

| Codec path | Hard frame input | Soft frame input | Data API input | Scratch/output bits |
| --- | --- | --- | --- | --- |
| AMBE 3600x2400 | `char ambe_fr[4][24]` | `mbe_soft_bit ambe_fr[4][24]` | `char ambe_d[49]` | `ambe_d[49]` |
| AMBE 3600x2450 | `char ambe_fr[4][24]` | `mbe_soft_bit ambe_fr[4][24]` | `char ambe_d[49]` | `ambe_d[49]` |
| IMBE 7200x4400 | `char imbe_fr[8][23]` | `mbe_soft_bit imbe_fr[8][23]` | `char imbe_d[88]` | `imbe_d[88]` |
| IMBE 7100x4400 | `char imbe_fr[7][24]` | `mbe_soft_bit imbe_fr[7][24]` | `char imbe_d[88]` | `imbe_d[88]` (converted to 7200 layout) |

Use hard-frame `mbe_process*Frame*` APIs when you want one-call decode+synthesis from interleaved codec frames. These APIs accept const frame arrays, run demod/ECC, populate `mbe_process_result`, and write the scratch/output parameter bits.

Use `mbe_decode*Frame()` / `mbe_decode*SoftFrame()` when you need staged decode. These helpers accept const frame input, fill hard parameter bits, optionally populate `mbe_process_result`, and return the corrected error total without synthesizing audio. Use `mbe_process*Data*` for later synthesis when you want to carry that result context forward.

Use `mbe_process*Data*` when you already have unpacked parameter bits.

IMBE 7100x4400 frame decoders convert their `imbe_d[88]` output to the 7200x4400/IMBE 4400 layout; synthesize converted data with the IMBE 4400 data APIs, passing along the decode's `mbe_process_result` so its C0/C4 context and `MBE_PROCESS_FLAG_PROVOICE` (ProVoice mute noise) apply.

- `mbe_ambe2400EncoderAlloc()` creates a caller-owned encoder context and FFT plan; `mbe_ambe2400EncoderReset(enc)` restarts its analysis state, and `mbe_ambe2400EncoderFree(enc)` releases it.
- `mbe_encodeAmbe2400Parms(enc, samples, ambe_d, cur_mp, prev_mp)` encodes 160 float PCM samples into 49 AMBE 2400 parameter bits. It is bit-compatible with this library's `mbe_decodeAmbe2400Parms()`/`mbe_processAmbe3600x2400*()` path and follows the D-STAR AMBE bit layout (interleave, scrambler and Golay parity cross-checked against the MMDVM tables). Its analysis follows the method of TIA-102.BABA chapter 5, and the spectral reconstruction it targets matches DVSI's AMBE-3000 D-STAR test vectors; on-air interoperability has not been verified.
- `mbe_encodeAmbe2400ParmsShort(enc, samples, ambe_d, cur_mp, prev_mp)` encodes 160 signed 16-bit PCM samples into 49 AMBE 2400 parameter bits.
- `mbe_encodeAmbe3600x2400Frame()` adds FEC and interleaving to 49 parameter bits, producing `char ambe_fr[4][24]`.
- `mbe_encodeDStarDVData()` packs a frame into nine D-STAR DV data bytes in air order, LSB first, without the sync word.
- `mbe_decodeDStarDVData()` unpacks nine D-STAR DV data bytes into `char ambe_fr[4][24]`.
- `mbe_ambe2450EncoderAlloc()`, `mbe_ambe2450EncoderReset()` and `mbe_ambe2450EncoderFree()` manage an AMBE+2 3600x2450 (DMR, NXDN, YSF, P25 Phase 2) encoder context. `mbe_encodeAmbe2450Parms(enc, samples, ambe_d, cur_mp, prev_mp)` and `mbe_encodeAmbe2450ParmsShort()` encode 160 float or 16-bit PCM samples into 49 parameter bits, quantized as TIA-102.BABA-1 clause 4 describes, and return `MBE_AMBE2450_FRAME_VOICE`, or `MBE_AMBE2450_FRAME_TONE` for a DTMF, KNOX, call-progress or single tone sent as a §7.2 tone frame. A call-progress tone is sent once it has filled three consecutive 20 ms analysis spans (an 80 ms tone always does; DVSI's encoder starts one frame earlier) and for up to two frames after it ends. A DTMF, KNOX or single tone is sent for the frames whose analysis span it fills at least 45%; where one changes directly to another, the frame whose span holds both carries the newer tone if it is a DTMF or KNOX tone filling the span's newest half, else the older tone if it fills the oldest half, as DVSI's encoder sends them. `mbe_encodeAmbe3600x2450Frame()` adds the Golay codes and the modulation of C1, producing `char ambe_fr[4][24]`.
- `mbe_imbe4400EncoderAlloc()`, `mbe_imbe4400EncoderReset()` and `mbe_imbe4400EncoderFree()` manage an IMBE 7200x4400 (P25 Phase 1) encoder context. `mbe_encodeImbe4400Parms(enc, samples, imbe_d, cur_mp, prev_mp)` and `mbe_encodeImbe4400ParmsShort()` encode 160 float or 16-bit PCM samples into 88 parameter bits, quantized as TIA-102.BABA chapter 6 describes, with the alternating synchronization bit of §6.5 in `imbe_d[87]`. `mbe_encodeImbe7200x4400Frame()` adds the Golay and Hamming codes and the modulation of vectors 1–6, producing `char imbe_fr[8][23]`.
- All three encoders share one speech analysis, and the two AMBE encoders one quantizer. Measured on DVSI's validation vectors against DVSI's own encoding of the same input, both decoded by this library, the AMBE+2 and IMBE encoders match its level within 0.1 dB (median) and the D-STAR encoder within 0.4 dB, all three sit closer to the input speech (log-spectral distance 4.8 against 5.0 dB for AMBE+2 and D-STAR, 4.7 against 4.9 dB for IMBE) and they make the same voicing decision for 79–85% of each 1 kHz band. On DVSI's rate-33 and D-STAR tone vectors the AMBE+2 and D-STAR encoders send DVSI's tone index for 98% of DVSI's tone frames, and no tone frame for any speech vector. The frame encoders reproduce DVSI's P25 and rate-33 frames bit for bit from their parameter bits. On-air interoperability has not been verified.

### Encoder Workflow

- Encoder state: use one `mbe_ambe2400_encoder` context per stream, with any number of contexts per thread; concurrent use of the same context requires external synchronization. Initialize with `mbe_ambe2400EncoderAlloc()` plus `mbe_initMbeParms()`, advance prediction with `mbe_moveMbeParms(cur_mp, prev_mp)` between frames, and restart with `mbe_ambe2400EncoderReset()` plus `mbe_initMbeParms()`. Encoding never allocates and does not modify `prev_mp`. State equivalence holds with both the `mbe_processAmbe2400*` path and a bare `mbe_decodeAmbe2400Parms()` chain. The analysis delay is about 10 ms; feed one final zero frame to flush the tail (a call-progress tone that ends with the input is held for two frames, so encode two to send them all). As with DVSI's encoder, quiet and silent input is coded as low-level voice and the decoded level follows the input level; there is no AGC. DTMF, call-progress and single tones are sent as D-STAR tone frames (b0 126), decided and timed as the AMBE+2 encoder decides its tone frames, since DVSI's D-STAR and rate-33 encoders send tone frames on the same frames; KNOX tones, which D-STAR cannot carry, are coded as voice. A tone frame leaves the decoder's prediction history unchanged, so `cur_mp` is then a copy of `prev_mp`.
- The AMBE+2 and IMBE encoders use the same contract and timing, with `mbe_ambe2450_encoder` or `mbe_imbe4400_encoder` contexts; `cur_mp` must not be `prev_mp`. Every IMBE frame and every AMBE+2 frame other than a tone frame is a voice frame. A tone frame leaves the decoder's prediction history unchanged, so `cur_mp` is then a copy of `prev_mp` and the usual `mbe_moveMbeParms(cur_mp, prev_mp)` keeps the history; to hear what was sent, run the emitted bits through `mbe_processAmbe2450Data()` with its own decoder state.

### Stateful Decode Workflow

- Keep one `mbe_parms` state triplet per audio stream/thread: `cur_mp`, `prev_mp`, and `prev_mp_enhanced`. The three must be distinct objects.
- In AMBE 3600x2450, `prev_mp` is the last valid voice frame (the prediction history) and `prev_mp_enhanced` is the last synthesized frame. When you drive `mbe_decodeAmbe2450Parms()` yourself, copy `cur_mp` into `prev_mp` only when `mbe_classifyAmbe2450Frame()` returns `MBE_AMBE2450_FRAME_VOICE`. `mbe_decodeAmbe2450Parms()` returns `MBE_AMBE2450_FRAME_VOICE` for silence frames too, as in 2.1, since both decode a model.
- Initialize once before decoding with `mbe_initMbeParms(&cur_mp, &prev_mp, &prev_mp_enhanced)`.
- Prefer `mbe_process*Frame*` APIs when you have raw hard-decision vocoder frames and do not need staged parameter handling.
- For soft-decision input, fill `mbe_soft_bit.bit` with the hard decision and `mbe_soft_bit.reliability` with confidence (`0` is erasure-like, `255` is highly reliable), then call `mbe_decode*SoftFrame()` or `mbe_process*SoftFrame*()`.
- Helper constructors are available for common inputs: `mbe_softBitsFromHard()` assigns a fixed reliability and validates hard bits, while `mbe_softBitsFromLlr()` maps positive signed LLRs to bit 1 with magnitude clamped to `0..255`.
- Processing APIs report frame state through `mbe_process_result`: `c0_errors`, `protected_errors`, IMBE-specific `c4_errors`, `total_errors`, and flags such as `MBE_PROCESS_FLAG_SOFT_INPUT`, `MBE_PROCESS_FLAG_C0_VALID`, `MBE_PROCESS_FLAG_C4_VALID`, `MBE_PROCESS_FLAG_TONE`, `MBE_PROCESS_FLAG_ERASURE`, `MBE_PROCESS_FLAG_REPEAT`, `MBE_PROCESS_FLAG_MUTE`, `MBE_PROCESS_FLAG_SILENCE` (AMBE 3600x2450 silence frames), and `MBE_PROCESS_FLAG_PROVOICE` (context set by the IMBE 7100x4400 decoders).
- Use `mbe_formatProcessResult()` when you need a compact status string from a result. It writes `'='` repeated `total_errors` times, then any `E`, `T`, `R`, and `M` flags in that order, truncated to the supplied buffer size. The silence flag is not rendered.
- Hard input bits must be exactly `0` or `1`; soft `mbe_soft_bit.bit` values must also be exactly `0` or `1`. Invalid pointers/counters return `MBE_STATUS_INVALID_ARGUMENT`; invalid bit values return `MBE_STATUS_INVALID_BITS`.
- For parameter-only processing, seed `mbe_process_result.total_errors` and any valid C0/C4 context before calling `mbe_process*Data*`.
- Use `mbe_versionString()` for the static NUL-terminated library version string.

### TETRA Decoding

```c
mbe_tetra_decoder* dec = mbe_tetraDecoderAlloc();      /* one context per stream */
uint8_t bits[MBE_TETRA_FRAME_BITS];                    /* B1..B137, one 0/1 byte each */
int16_t pcm[MBE_TETRA_FRAME_SAMPLES];                  /* 240 samples, 30 ms at 8 kHz */
/* ... per received speech frame ... */
int status = mbe_tetraDecodeFrame(dec, crc_failed ? NULL : bits, crc_failed, pcm);
/* ... at the end of the call ... */
mbe_tetraDecoderFree(dec);
```

- Input is the 137 type-1 bits of one speech frame in the order of EN 300 395-2 clause 4.2.2.7, tables 3 and 4 (B1 is the most significant bit of the first LSP index), as a TETRA channel decoder delivers them. Each byte must be 0 or 1.
- Pass a nonzero `bad_frame` when the class-2 CRC failed or the frame was stolen for signalling; the frame is then concealed as clause 4.2.3.2 describes (previous LSPs, the last subframe-4 pitch, energies lowered 1.5 dB per subframe, previous innovation indices) and `bits` is not read. Bad frames before the first good frame since allocation or `mbe_tetraDecoderReset()` give silence; as in ETSI's reference decoder, the output after them can start with a burst.
- Output is plain 16-bit PCM at the level of ETSI's reference decoder; there is no float variant and no mbelib float scale.
- Returns 0, `MBE_STATUS_INVALID_ARGUMENT` (NULL `dec` or `pcm`, NULL `bits` on a good frame) or `MBE_STATUS_INVALID_BITS`. A rejected frame leaves the context and `pcm` untouched, so it can be retried as a bad frame.
- The context holds all decoder state and is not shared: use one per stream, any number per thread, and lock externally for concurrent use of one context. Decoding never allocates. The arithmetic is integer only, so the output is identical on every platform and build configuration.
- Conformance: the decoder passes the EN 300 395-4 decoder test: TE1_46.CHD decodes to TE2_128.PCM byte for byte. Its output also matches ETSI's reference decoder on every other stream compared: TE3, the tested loss patterns (including bad frames before the first good frame) and about 2.1 million frames of synthetic stress streams. `docs/tetra-acelp.md` records how the details the standard's text leaves open were resolved, and the measurements.

### Audio Sample Scaling (Float vs int16)

This section covers the IMBE/AMBE decoders. The TETRA decoder writes 240-sample int16 frames with plain saturation and has no float variant ([TETRA decoding](#tetra-decoding)).

- The IMBE/AMBE decoders synthesize 8 kHz audio in 160-sample frames.
- The `short` entry points write 16-bit PCM with soft clipping (~95% full-scale).
- The `*f` entry points return mbelib’s historical float scale (not normalized `[-1, +1]`). `mbe_floattoshort()` applies the same `* 7.0` scaling and clipping used by the `short` APIs.
- To feed a normalized float pipeline, scale each float sample by `(7.0f / 32768.0f)` (range is approximately `[-0.95, +0.95]` after soft clipping).
- Decoded speech comes out at the level of the original speech, the same level DVSI's AMBE-3000 decoders produce on identical bits. Releases up to 2.2.x played speech about 17 dB louder and soft-clipped 5–7% of the samples of normally recorded speech; adjust any downstream gain that compensated for that.

## Windows (MSVC) Quickstart

- Open the "x64 Native Tools Command Prompt for VS".
- From the repository root:

```
cmake --preset dev-release
cmake --build --preset dev-release --config Release -j
ctest --preset dev-release -C Release
cmake --install build/dev-release --config Release
```

Consuming with CMake on Windows (link static to avoid DLL path issues):

```cmake
cmake_minimum_required(VERSION 3.20)
project(consumer C)
find_package(mbe-neo CONFIG REQUIRED)
add_executable(consumer consumer.c)
target_link_libraries(consumer PRIVATE mbe_neo::mbe_static) # or mbe_neo::mbe_shared
```

## pkg-config on Windows (MSYS2/MinGW)

- Install MSYS2 and open a MinGW64 shell (e.g., UCRT64 or MINGW64).
- Install toolchain and pkg-config:

```
pacman -S --needed mingw-w64-x86_64-toolchain mingw-w64-x86_64-cmake mingw-w64-x86_64-pkg-config
```

- Configure, build, and install using the MinGW generator (example to the default /mingw64 prefix):

```
cmake -G "MinGW Makefiles" -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
cmake --install build --prefix /mingw64
```

- Compile a consumer using pkg-config:

```
cat > consumer.c << 'EOF'
#include <stdio.h>
#include <mbelib-neo/mbelib.h>
int main(void) { printf("%s\n", mbe_versionString()); }
EOF
cc consumer.c $(pkg-config --cflags --libs libmbe-neo) -o consumer.exe
```

Notes

- If you install to a custom prefix, set `PKG_CONFIG_PATH="<prefix>/lib/pkgconfig:$PKG_CONFIG_PATH"`.
- For shared builds, ensure `<prefix>/bin` is on `PATH` (so the DLL is found) or copy the DLL next to your `.exe`.
- To prefer static linking via pkg-config, you can try `pkg-config --static --libs libmbe-neo` (requires static libs available) or use the CMake package and link `mbe_neo::mbe_static`.

## Audio Quality Improvements

mbelib-neo combines regenerated MBE voiced phase with TIA-102.BABA smoothing and FFT-based unvoiced synthesis:

- **FFT-based unvoiced synthesis** (Algorithms #117-126): Uses 256-point FFT with band-level scaling instead of the legacy oscillator bank approach. Provides cleaner, more natural unvoiced sounds with proper spectral shaping.

- **Weighted Overlap-Add (WOLA)** (Algorithm #126): Unvoiced and voiced synthesis share the symmetric spec-exact trapezoidal window, with complementary weights across each 160-sample frame transition.

- **Adaptive smoothing** (Algorithms #111-116): Error-rate-based parameter smoothing that gracefully handles corrupted frames. Includes local energy tracking, adaptive voicing thresholds, and amplitude scaling.

- **Regenerated voiced phase**: The odd log-magnitude kernel from [US 5,701,390, Eqs. 7–9](https://patents.google.com/patent/US5701390A/en) derives harmonic phase from the enhanced, smoothed spectral envelope. The shared synthesizer applies it to all four codecs without changing the public API or parameter layout. Existing phase/amplitude interpolation remains in place; fully voiced output no longer depends on the unvoiced-noise RNG seed.

- **Codec-specific frame repeat/muting**: IMBE mutes on max repeats or the error-rate threshold, and IMBE prolonged repeat headroom resets to a default model state. D-STAR mutes on max repeats and, for hard-decision input, while its error rate is above 0.042, which approximates the muting of DVSI's AMBE-3000 under sustained channel errors (it starts sooner; see [DVSI parity](docs/dvsi-parity.md#d-star-muting-under-channel-errors)). In every codec, a repeated frame keeps its own error accounting and continues the unvoiced-noise sequence; only the model is repeated.

- **AMBE 3600x2450 frame types per TIA-102.BABA-1** (P25 Half-Rate Vocoder Addendum):
  - **Silence frames** (b0 124/125) use ω₀ = 2π/32, L = 14 and all bands unvoiced (§4.1). They are synthesized but never used for prediction, so gain and log-magnitude history stay with the last voice frame (§4.3, §4.4.1 eq. 26, §4.4.3 eq. 43).
  - **Error counts** (§5.5): every bit of the received C0 and C1 codewords, parity bits included, that differs from the corrected codeword, plus C0's extended parity bit when it disagrees with the corrected codeword (4 marks a detected, uncorrectable C0). Soft decisions count each such bit by its reliability.
  - **Repeats** (§5.6): erasure (b0 120–123), or C0 errors ≥ 4. DVSI's AMBE-3000 does not apply eq. 57–58's second condition (C0 ≥ 2 with ≥ 6 total), and neither does this library. These criteria apply to every frame, before tone classification. A repeat replays the last synthesized frame unchanged (no re-enhancement or adaptive smoothing) and leaves the history untouched.
  - **Departures followed from DVSI's AMBE-3000**: the pitch law log2 f0 = −4.322605 − 0.0220427 b0 in place of the Annex A table (12 harmonics, not 11, at b0 17), and u3's bits 8–5 carrying b4(2), b4(1), b4(0), b3(0) where the v1.0.5 text of Table 8 prints b3(0) first; DVSI's decoder and encoder both use them ([DVSI parity](docs/dvsi-parity.md)).
  - **Tones** (§7, §7.3): a frame whose first six bits of u0 equal 63 is a tone frame, whatever its b0 would read as (a single tone can read as silence). An invalid tone index is an erasure (flagged `ERASURE` and `TONE`), and so is a tone frame whose redundant tone fields disagree (a local consistency check; the spec leaves this to the decoder). Tone ID 255 is a zero-amplitude tone. Each tone component plays at the §7.2 level, 0.711 dB per AD step from +3.17 dBm0 at AD 127 (at the reference DVSI's decoder uses), and dual tones carry both components at that level. Frequencies are the nominal values of the tone table; DVSI's decoder approximates dual tones as two harmonics of one fundamental, up to 3% off nominal.
  - **Muting** (§5.7): when the error rate exceeds 0.096, or instead of the 4th consecutive repeat, output uniform noise in [−5, 5] on the synthesized-speech scale.
  - **Recovery after mutes and tones**: a mute or a tone frame also silences the last synthesized frame, so the next synthesized frame fades in instead of overlapping the speech from before it, and a repeat right after either replays silence. The spec doesn't define the synthesis state across these frames.

- **DVSI parity**: on DVSI's AMBE-3000 test vectors, D-STAR's gain is absolute (2 Dg[b2] − 0.09, not rate 33's differential law, which played onsets after silence up to 16 dB low), every codec renders the phase of the output high-pass whose magnitude it already rendered, and voiced and unvoiced harmonics play 0.3 dB louder and 0.4 dB quieter, as DVSI's decoders do. The encoders quantize with the same laws. What was measured, and what still differs, is in [`docs/dvsi-parity.md`](docs/dvsi-parity.md).

- **D-STAR tones**: single tones 5–122 as AMBE+2, DTMF 128–143 (128 + 4 × column + row) and call-progress tones 144–147, at the level the 8-bit tone volume gives on DVSI's decoder. The zero-volume frame (b0 127, tone index 128) that earlier versions of this library's encoder sent for silence plays comfort noise and resets the decoder.

- **LCG noise generator with buffer overlap**: TIA-102.BABA §11.2 linear congruential generator for deterministic noise, with 96-sample overlap for smooth continuity between frames.

- **Mute noise**: P25 IMBE and AMBE 3600x2450 mute with the spec level, uniform in [−5, 5] at the int16 output (±5/7 in the float output, which is int16 / 7; TIA-102.BABA §7.8, TIA-102.BABA-1 §5.7). D-STAR, ProVoice (not a TIA-102 codec; the 7100x4400 frame APIs, or the IMBE 4400 data API given a result carrying `MBE_PROCESS_FLAG_PROVOICE`) and direct `mbe_synthesizeSpeechf()` callers use the library comfort-noise level (`0.003` gain semantics, also used by `mbe_synthesizeComfortNoisef()`). All of them draw from a Java `Random`-compatible per-thread RNG.

- **Nyquist guard**: the shared synthesizer skips voiced harmonics at or above Nyquist (`l * w0 >= pi`) instead of rendering them as aliases. Decoded models never contain such harmonics; the guard protects caller-supplied models.

The opt-in [encode/decode quality pipeline](docs/testing.md#speech-quality-evaluation) compares a frozen baseline and candidate using identical encoded frames. It reports spectral, crest-factor, envelope, and reference-matched frame-join measurements; these are diagnostics, not a substitute for listening or a standardized perceptual score.


## API Notes

- Public API is prefixed `mbe_` and declared in `mbelib.h`.
- Float and 16‑bit PCM variants are provided (e.g., `mbe_processAmbe3600x2400Framef` and `mbe_processAmbe3600x2400Frame`).
- Version macro `MBELIB_VERSION` is defined in the generated header `mbelib-neo/version.h`.
- `mbe_versionString()` returns a const pointer to the version string.
- Processing APIs return an `int` error total and use `mbe_process_result` for decode/synthesis status.
- Soft-decision ECC helpers are public for Golay(23,12), Hamming(15,11), and the IMBE 7100x4400 Hamming mapping.
- Unvoiced synthesis uses the TIA-102.BABA §11.2 LCG state carried in `mbe_parms` (`noiseSeed`/`noiseOverlap`), with per-thread cold-start seeding via `mbe_setThreadRngSeed(uint32_t)`.
- ABI: v2.0.0 breaks ABI from v1. The shared library `SOVERSION` follows the project major version; minor updates within a major version aim to remain ABI compatible.

### Determinism & RNG

- `mbe_setThreadRngSeed(seed)` seeds both thread-local comfort-noise RNG state and the next unvoiced LCG cold start. For reproducible output, set it per thread before synthesis.
- `mbe_setThreadRngSeed(0)` is accepted and remapped internally to a non-zero seed. Use an explicit non-zero seed when exact reproducibility matters across builds.
- Unvoiced noise progression after cold start is driven by the per-frame LCG state in `mbe_parms`, so deterministic playback requires carrying frame state forward consistently.
- Runtime synthesis helpers (RNG state and FFT plan) are thread-local; do not share mutable decode state (`mbe_parms`) across threads unless you synchronize externally.
- Frame handling differs per codec: IMBE uses error-rate muting and a repeat-headroom reset (with the TIA-102.BABA mute-noise level for P25, library comfort noise for ProVoice), D-STAR uses repeat-driven muting plus an error-rate mute for hard-decision input, and AMBE 3600x2450 follows TIA-102.BABA-1 (see Audio Quality Improvements).
- Enabling `MBELIB_ENABLE_SIMD=ON` selects vectorized math when the compiler target supports it, with
  scalar fallback otherwise. This can change
  floating‑point rounding at the bit level. Tests enforce exactness for int16 on x86 in Debug, and
  sanity bounds elsewhere.

## Benchmarks (Optional)

Build micro-benchmarks:

```
cmake --preset dev-release -DMBELIB_BUILD_BENCHMARKS=ON
cmake --build --preset dev-release -j --target bench_synth bench_unvoiced bench_convert bench_encode
```

Run benchmark executables:

```
./build/dev-release/bench_synth
./build/dev-release/bench_unvoiced
./build/dev-release/bench_convert
./build/dev-release/bench_encode
```

Scalar-vs-SIMD comparison for all three encoders, voiced/unvoiced synthesis and PCM conversion (builds ad hoc comparison trees under `build/bench-compare-scalar/` and `build/bench-compare-simd/`):

```
tools/bench_compare.sh
```

## Tests and Examples

- Run tests with `ctest --preset dev-debug -V` (or `ctest -V` from the build directory).
- Included tests: `test_api` (version/header/result helpers), `test_ecc` (hard and soft Golay/Hamming), `test_noise_determinism` (unvoiced RNG/frame-state determinism), `test_params` (parameter/synthesis behavior, soft frame decode, and v2 wrappers), `test_floattoshort_parity` (exact float-to-int16 conversion parity), `test_ambe2450_frame_types` (AMBE 3600x2450 silence, repeat, erasure, tone and mute handling per TIA-102.BABA-1), `test_tones` (AMBE+2 and D-STAR tone levels and frequencies against the DVSI-calibrated laws), `test_golden_pcm` (golden hash regression checks, including voice-only AMBE 2450 and D-STAR sequences), `test_tetra_decoder` (TETRA decoding stages, concealment, API contract and stream hashes), `test_fixed_point` (the TETRA decoder's saturating operators), `test_tetra_shared_api` (TETRA entry points through the shared library), `test_tetra_tables` (table generators and provenance), `test_tetra_conformance_tools` (the TETRA comparison tool).
- Example: `examples/print_version.c` shows linking and header usage.
- WAV round trip: `./build/dev-debug/dstar_encode < input.wav > output.dstar`, then `./build/dev-debug/dstar_decode < output.dstar > output.wav`. These example binaries are not installed. They use binary stdin/stdout, accept no path arguments, and send diagnostics to stderr. The private `.dstar` container is not a D-STAR air-interface stream.
- When Python 3.7 or newer is available, CTest also checks the D-STAR examples through stdin/stdout pipes, including malformed WAVs, exact silence, and the final flush frame.
- Golden hash helper: `gen_golden` (available when `MBELIB_BUILD_TESTS=ON`, default) prints current FNV-1a reference values for synthesis/conversion regression workflows (`cmake --build build/dev-debug --target gen_golden && ./build/dev-debug/gen_golden`).

## Documentation

Optional Doxygen documentation can be generated:

```
cmake --preset dev-debug -DMBELIB_BUILD_DOCS=ON
cmake --build --preset dev-debug --target docs
# Output in build/docs/html
```

The generated site focuses on the public API (`include/`) and bundled examples.

Project documentation and policies:

- Contribution process, DCO, coding standards, review requirements, and test policy: `CONTRIBUTING.md`
- Defect reporting: `docs/issue-reporting.md`
- Architecture and trust boundaries: `docs/architecture.md`
- Build and installation policy: `docs/build-installation.md`
- Security requirements and design: `docs/security-requirements.md`
- Dependency management and monitoring: `docs/dependencies.md`
- OpenSSF OSPS Baseline evidence: `docs/openssf-baseline.md`
- Testing, CI, coverage target, and dynamic analysis: `docs/testing.md`
- Parity with DVSI's AMBE-3000 decoders and encoders (measurements, departures from the specification, known differences): `docs/dvsi-parity.md`
- Release verification and signing: `docs/release-verification.md`
- Supply-chain guardrails: `docs/supply-chain-guardrails.md`
- Code-quality guardrails: `docs/code-quality-guardrails.md`

## Project Layout

- Public headers: `include/mbelib-neo/`
- Sources: `src/core/`, `src/ecc/`, `src/ambe/`, `src/imbe/`, `src/tetra/`
- Internal headers: `src/internal/`
- External libraries: pinned PFFFT fork populated by `cmake/Pffft.cmake` (retained texts: `LicenseRef-PFFFT`)
- Tests: `tests/` • Examples: `examples/` • Benchmarks: `bench/`
- Developer tooling and CI parity scripts: `tools/`

## Contributing

- Read `CONTRIBUTING.md` before opening a pull request.
- Follow `.clang-format` (LLVM style, 4‑space indent, 120 cols). You can run `tools/format.sh`.
- Static analysis scripts (CI-aligned; CI and pre-push/preflight use strict mode where applicable):
  - `tools/clang_tidy.sh` (promotes broad bugprone/performance/portability findings; targeted TUs supported).
  - `tools/cppcheck.sh` (strict uses exhaustive value-flow, inconclusive findings, and targeted TUs).
  - `tools/iwyu.sh` (strict include hygiene via include-what-you-use, including project headers; excludes `src/external`).
  - `tools/gcc_fanalyzer.sh` (strict GCC `-fanalyzer` plus additional high-signal GCC warnings; excludes `src/external`).
  - `tools/scan_build.sh` (strict Clang Static Analyzer with extra security/portability checkers; excludes `src/external`).
  - `tools/semgrep.sh` (strict SAST with default, C, and security-audit rule packs).
  - `tools/lizard.sh` (strict complexity/length/argument budgets; excludes `src/external`).
- Git hooks: `tools/install-git-hooks.sh` enables auto-format on commit and CI-style pre-push checks.
- Manual preflight runner: `tools/preflight_ci.sh` runs the local CI quality gates without pushing.
- Prefer keeping internal symbols `static` and declarations in headers where shared.
- Before sending changes: build locally, run `ctest -V`, and ensure examples still link.
