// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Unit tests for ECC helpers (Golay and Hamming variants).
 */
#include <assert.h>
#include <string.h>
// Embedded copies of generator tables used for test expectations
static const int hammingGenerator[4] = {0x7f08, 0x78e4, 0x66d2, 0x55b1};
static const int imbe7100x4400hammingGenerator[4] = {0x7ac8, 0x3d64, 0x1eb2, 0x7591};
static const int golayGenerator[12] = {0x63a, 0x31d, 0x7b4, 0x3da, 0x1ed, 0x6cc,
                                       0x366, 0x1b3, 0x6e3, 0x54b, 0x49f, 0x475};
#include "mbelib-neo/mbelib.h"

// make stderr unbuffered for debug visibility under ctest
#include <stdio.h>

/**
 * @brief Flip a single bit in a bit-vector.
 * @param bits Bit array of chars containing 0/1 values.
 * @param idx  Index of bit to toggle.
 */
static void
flip_bit(char* bits, int idx) {
    bits[idx] = bits[idx] ? 0 : 1;
}

static void
make_soft_bits(const char* bits, mbe_soft_bit* soft, int count, int weak0, int weak1, int weak2, int weak3) {
    for (int i = 0; i < count; ++i) {
        soft[i] = mbe_softBitFromHard(bits[i], 200);
    }
    if (weak0 >= 0) {
        soft[weak0].reliability = 1;
    }
    if (weak1 >= 0) {
        soft[weak1].reliability = 1;
    }
    if (weak2 >= 0) {
        soft[weak2].reliability = 1;
    }
    if (weak3 >= 0) {
        soft[weak3].reliability = 1;
    }
}

/**
 * @brief Compute 4-bit syndrome for a 15-bit codeword using a generator.
 * @param code      Codeword bits as 0/1 chars, LSB at index 0.
 * @param generator Array of 4 generator row masks.
 * @return Syndrome (LSB-first) in range [0, 15].
 */
static int
compute_syndrome_with_generator(const char code[15], const int generator[4]) {
    int block = 0;
    for (int i = 14; i >= 0; --i) {
        block <<= 1;
        block |= (code[i] ? 1 : 0);
    }
    int syndrome = 0;
    for (int r = 0; r < 4; ++r) {
        int stmp = block & generator[r];
        int sbit = (stmp & 1);
        for (int j = 0; j < 14; ++j) {
            stmp >>= 1;
            sbit ^= (stmp & 1);
        }
        syndrome |= (sbit << r);
    }
    return syndrome;
}

/**
 * @brief Determine parity bit positions (those not in data_pos).
 * @param data_pos  11 indices of data positions (0..14).
 * @param parity_pos Output 4 indices for parity positions.
 */
static void
derive_parity_positions(const int data_pos[11], int parity_pos[4]) {
    int p = 0;
    for (int i = 0; i < 15; ++i) {
        int is_data = 0;
        for (int d = 0; d < 11; ++d) {
            if (data_pos[d] == i) {
                is_data = 1;
                break;
            }
        }
        if (!is_data) {
            parity_pos[p++] = i;
        }
    }
}

/**
 * @brief Encode a (15,11) Hamming codeword for given data positions.
 *
 * Brute-forces the 4 parity bits (16 combinations) until syndrome is zero.
 *
 * @param generator  Generator row masks (4 entries).
 * @param data_pos   11 indices of data positions (0..14).
 * @param data_in    11 data bits (0/1 chars) mapped to data_pos.
 * @param code       Output encoded 15-bit codeword (0/1 chars).
 * @return 1 on success, 0 if no parity combination yields zero syndrome.
 */
static int
encode_hamming15_with_generator(const int generator[4], const int data_pos[11], const char data_in[11], char code[15]) {
    for (int i = 0; i < 15; ++i) {
        code[i] = 0;
    }
    for (int i = 0; i < 11; ++i) {
        code[data_pos[i]] = (data_in[i] ? 1 : 0);
    }
    int parity_pos[4];
    derive_parity_positions(data_pos, parity_pos);
    // brute-force 4 parity bits (16 combos) to satisfy parity equations
    for (int bits = 0; bits < 16; ++bits) {
        for (int k = 0; k < 4; ++k) {
            code[parity_pos[k]] = ((bits >> k) & 1);
        }
        int syn = compute_syndrome_with_generator(code, generator);
        if (syn == 0) {
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Convert a 4-bit syndrome into a (1<<bit) correction mask.
 * @param syndrome  4-bit syndrome value (LSB-first).
 * @param generator Generator row masks (4 entries).
 * @return Bit mask with one bit set (1<<bit), or 0 if not found.
 */
static int
correction_mask_from_generator(int syndrome, const int generator[4]) {
    if (syndrome == 0) {
        return 0;
    }
    for (int j = 0; j < 15; ++j) {
        int syn = 0;
        for (int r = 0; r < 4; ++r) {
            syn |= (((generator[r] >> j) & 1) << r);
        }
        if (syn == syndrome) {
            return (1 << j);
        }
    }
    return 0;
}

/* Independent oracle that scores every codeword: reconstruct candidates with
 * the original parity search, and score each bit individually. Deliberately
 * shares neither tables nor scoring/tie-ranking machinery with the optimized
 * decoder. */
static char reference_words[3][4096][23];

static void
init_reference_words(void) {
    const int positions[2][11] = {{2, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14}, {4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14}};
    for (unsigned d = 0; d < 4096u; ++d) {
        unsigned ecc = 0;
        for (int i = 0; i < 12; ++i) {
            if ((d >> (11 - i)) & 1u) {
                ecc ^= (unsigned)golayGenerator[i];
            }
        }
        unsigned word = (d << 11) | ecc;
        for (int i = 0; i < 23; ++i) {
            reference_words[0][d][i] = (char)((word >> i) & 1u);
        }
    }
    for (int variant = 0; variant < 2; ++variant) {
        for (unsigned d = 0; d < 2048u; ++d) {
            char data[11];
            for (int i = 0; i < 11; ++i) {
                data[i] = (char)((d >> i) & 1u);
            }
            int ok = encode_hamming15_with_generator(variant ? imbe7100x4400hammingGenerator : hammingGenerator,
                                                     positions[variant], data, reference_words[variant + 1][d]);
            assert(ok);
        }
    }
}

static int
reference_soft(const mbe_soft_bit* in, char* out, int variant) {
    int width = variant == 0 ? 23 : 15;
    int first = variant == 0 ? 11 : 0;
    int count = variant == 0 ? 4096 : 2048;
    char hard_in[23], hard[23];
    for (int i = 0; i < width; ++i) {
        hard_in[i] = (char)in[i].bit;
    }
    if (variant == 0) {
        (void)mbe_golay2312(hard_in, hard);
    } else if (variant == 1) {
        (void)mbe_hamming1511(hard_in, hard);
    } else {
        (void)mbe_7100x4400hamming1511(hard_in, hard);
    }
    int best_score = 100000, best_diffs = 100, best_hard = 0;
    for (int d = 0; d < count; ++d) {
        const char* row = reference_words[variant][d];
        int score = 0, diffs = 0, matches = 1;
        for (int i = 0; i < width; ++i) {
            score += row[i] != hard_in[i] ? in[i].reliability : 0;
            if (i >= first) {
                diffs += row[i] != hard_in[i];
                matches &= row[i] == hard[i];
            }
        }
        if (score < best_score || (score == best_score && matches > best_hard)
            || (score == best_score && matches == best_hard && diffs < best_diffs)) {
            memcpy(out, row, (size_t)width);
            best_score = score;
            best_diffs = diffs;
            best_hard = matches;
        }
    }
    for (int i = 0; i < first; ++i) {
        out[i] = hard_in[i];
    }
    return best_diffs;
}

static void
test_soft_differential(void) {
    int (*const decode[3])(const mbe_soft_bit*, char*) = {mbe_golay2312Soft, mbe_hamming1511Soft,
                                                          mbe_7100x4400hamming1511Soft};
    unsigned rng = 0x873fa11u;
    init_reference_words();
    for (int variant = 0; variant < 3; ++variant) {
        int width = variant == 0 ? 23 : 15;
        for (int trial = 0; trial < 1024; ++trial) {
            mbe_soft_bit soft[23];
            for (int i = 0; i < width; ++i) {
                rng = rng * 1664525u + 1013904223u;
                soft[i].bit = (unsigned char)(rng >> 31);
                switch (trial % 7) {
                    case 0: soft[i].reliability = 0; break;
                    case 1: soft[i].reliability = 255; break;
                    case 2: soft[i].reliability = (unsigned char)((rng >> 16) & 1u); break;
                    case 3: soft[i].reliability = i == trial % width ? 255 : 0; break;
                    /* Small weights tie many candidates at the search's cost bound. */
                    case 4: soft[i].reliability = (unsigned char)((rng >> 16) & 3u); break;
                    /* Mostly confident words with a few weak bits prune hardest. */
                    case 5: soft[i].reliability = i % 4 == trial % 4 ? (unsigned char)((rng >> 16) & 15u) : 255; break;
                    default: soft[i].reliability = (unsigned char)(rng >> 16); break;
                }
            }
            char expected[23], actual[23];
            int errors = reference_soft(soft, expected, variant);
            assert(decode[variant](soft, actual) == errors);
            assert(memcmp(actual, expected, (size_t)width) == 0);
        }
        /* Every clean candidate, including the entire generated codebook. */
        int count = variant == 0 ? 4096 : 2048;
        for (int d = 0; d < count; ++d) {
            mbe_soft_bit soft[23];
            char actual[23];
            assert(mbe_softBitsFromHard(reference_words[variant][d], soft, (size_t)width, 255) == 0);
            assert(decode[variant](soft, actual) == 0);
            assert(memcmp(actual, reference_words[variant][d], (size_t)width) == 0);
        }
    }
}

/**
 * @brief Test entry: exercises Hamming and Golay decoders.
 */
int
main(void) {
    test_soft_differential();
    setvbuf(stderr, NULL, _IONBF, 0);

    // Hamming (15,11): fixed-point and data invariance under single-bit errors
    {
        // Data positions (0-based bit indices): all except parity 0,1,3,7
        int data_pos[11] = {2, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14};

        // Start from explicit 11-bit data and encode to a valid codeword
        char data11[11];
        for (int i = 0; i < 11; ++i) {
            data11[i] = (i % 2);
        }
        char code[15];
        int parity_pos[4];
        derive_parity_positions(data_pos, parity_pos);
        int ok = encode_hamming15_with_generator(hammingGenerator, data_pos, data11, code);
        assert(ok == 1);
        (void)ok; /* Suppress unused-but-set warning when asserts disabled */

        // Extract data bits
        char data_ref[11];
        for (int i = 0; i < 11; ++i) {
            data_ref[i] = code[data_pos[i]];
        }

        // Decoding a codeword should be a fixed point
        char code2[15];
        int fixed_point_errs = mbe_hamming1511(code, code2);
        assert(fixed_point_errs == 0);
        (void)fixed_point_errs; /* Suppress unused-but-set warning when asserts disabled */
        assert(memcmp(code, code2, sizeof(code)) == 0);

        // Sanity: bit-level correction in integer domain should restore original block
        int block_orig = 0;
        for (int i = 14; i >= 0; --i) {
            block_orig <<= 1;
            block_orig |= (code[i] ? 1 : 0);
        }
        for (int j = 0; j < 15; ++j) {
            int err_block = block_orig ^ (1 << j);
            // compute syndrome identical to decoder
            int syn = 0;
            for (int r = 0; r < 4; ++r) {
                int stmp = err_block & hammingGenerator[r];
                int sbit = (stmp & 1);
                for (int t = 0; t < 14; ++t) {
                    stmp >>= 1;
                    sbit ^= (stmp & 1);
                }
                syn |= (sbit << r);
            }
            if (syn != 0) {
                int fixed_block = err_block ^ correction_mask_from_generator(syn, hammingGenerator);
                if (fixed_block != block_orig) {
                    fprintf(stderr, "int-domain correction mismatch at bit %d (syn=%d)\n", j, syn);
                    return 5;
                }
            }
        }

        // Flip each bit and ensure decode restores original codeword and data
        int failures = 0;
        for (int k = 0; k < 15; ++k) {
            char err[15];
            memcpy(err, code, sizeof(err));
            int idx = 14 - k; // flip MSB-first to match generator orientation
            flip_bit(err, idx);
            char fixed[15];
            int errs3 = mbe_hamming1511(err, fixed);
            assert(errs3 >= 1);
            (void)errs3; /* Suppress unused-but-set warning when asserts disabled */
            if (memcmp(code, fixed, sizeof(code)) != 0) {
                fprintf(stderr, "mismatch at bit %d for standard hamming\n", k);
                fprintf(stderr, "orig: ");
                for (int b = 14; b >= 0; --b) {
                    fprintf(stderr, "%d", code[b]);
                }
                fprintf(stderr, "\nfixd: ");
                for (int b = 14; b >= 0; --b) {
                    fprintf(stderr, "%d", fixed[b]);
                }
                fprintf(stderr, "\n");
                // continue to verify the data bits still match
            }
            // don't require bit-perfect codeword equality; require data equality below
            // extract data bits by re-encoding fixed to a canonical codeword and comparing data
            // simpler: just pick out data bit positions
            char data_now[11];
            for (int i = 0; i < 11; ++i) {
                data_now[i] = fixed[data_pos[i]];
            }
            if (memcmp(data_ref, data_now, sizeof(data_ref)) != 0) {
                fprintf(stderr, "data mismatch at bit %d for standard hamming\n", k);
                ++failures;
            }
        }
        if (failures) {
            return 4;
        }

        {
            char err[15];
            memcpy(err, code, sizeof(err));
            flip_bit(err, 2);
            flip_bit(err, 4);
            mbe_soft_bit soft[15];
            make_soft_bits(err, soft, 15, 2, 4, -1, -1);
            char fixed[15];
            int soft_errs = mbe_hamming1511Soft(soft, fixed);
            assert(soft_errs == 2);
            assert(memcmp(code, fixed, sizeof(code)) == 0);
        }
    }

    // IMBE 7100x4400 Hamming variant: same properties
    {
        int data_pos[11] = {4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

        char data11[11];
        for (int i = 0; i < 11; ++i) {
            data11[i] = ((i % 3) == 0);
        }
        char code[15];
        int ok2 = encode_hamming15_with_generator(imbe7100x4400hammingGenerator, data_pos, data11, code);
        assert(ok2 == 1);
        (void)ok2; /* Suppress unused-but-set warning when asserts disabled */

        char data_ref[11];
        for (int i = 0; i < 11; ++i) {
            data_ref[i] = code[data_pos[i]];
        }

        char code2[15];
        int fixed_point_errs = mbe_7100x4400hamming1511(code, code2);
        assert(fixed_point_errs == 0);
        (void)fixed_point_errs; /* Suppress unused-but-set warning when asserts disabled */
        assert(memcmp(code, code2, sizeof(code)) == 0);

        for (int k = 0; k < 15; ++k) {
            char err[15];
            memcpy(err, code, sizeof(err));
            int idx = 14 - k; // flip MSB-first to match generator orientation
            flip_bit(err, idx);
            char fixed[15];
            int errs3 = mbe_7100x4400hamming1511(err, fixed);
            assert(errs3 >= 1);
            (void)errs3; /* Suppress unused-but-set warning when asserts disabled */
            if (memcmp(code, fixed, sizeof(code)) != 0) {
                fprintf(stderr, "mismatch at bit %d for 7100 hamming\n", k);
                return 3;
            }
            assert(memcmp(code, fixed, sizeof(code)) == 0);
            char data_now[11];
            for (int i = 0; i < 11; ++i) {
                data_now[i] = fixed[data_pos[i]];
            }
            assert(memcmp(data_ref, data_now, sizeof(data_ref)) == 0);
        }

        {
            char err[15];
            memcpy(err, code, sizeof(err));
            flip_bit(err, 2);
            flip_bit(err, 4);
            mbe_soft_bit soft[15];
            make_soft_bits(err, soft, 15, 2, 4, -1, -1);
            char fixed[15];
            int soft_errs = mbe_7100x4400hamming1511Soft(soft, fixed);
            assert(soft_errs == 2);
            assert(memcmp(code, fixed, sizeof(code)) == 0);
        }

        for (unsigned int data = 0; data < 2048u; ++data) {
            char all_data[11];
            char clean[15];
            char fixed[15];
            mbe_soft_bit soft[15];

            for (int i = 0; i < 11; ++i) {
                all_data[i] = (char)((data >> i) & 1u);
            }
            int ok_all = encode_hamming15_with_generator(imbe7100x4400hammingGenerator, data_pos, all_data, clean);
            assert(ok_all == 1);
            (void)ok_all;

            make_soft_bits(clean, soft, 15, -1, -1, -1, -1);
            int soft_errs = mbe_7100x4400hamming1511Soft(soft, fixed);
            if (soft_errs != 0 || memcmp(clean, fixed, sizeof(clean)) != 0) {
                fprintf(stderr, "clean 7100 soft hamming mismatch for data 0x%03x\n", data);
                return 6;
            }
        }
    }

    // Golay (23,12): corrects any single-bit error in the 23-bit codeword
    {
        // Choose a 12-bit data value
        unsigned int data = 0xA55 & 0xFFFu;
        // Compute expected ECC using generator table mapping used in ecc.c
        unsigned int ecc = 0u;
        for (int i = 0; i < 12; ++i) {
            // i=0 corresponds to MSB of the 12 data bits (bit 11)
            if ((data >> (11 - i)) & 1u) {
                ecc ^= (unsigned int)golayGenerator[i];
            }
        }
        // Compose 23-bit block: [data (12b) | ecc (11b)]
        unsigned int block = ((data & 0x0FFFu) << 11) | (ecc & 0x7FFu);

        // Introduce a single-bit error in the 23-bit block
        unsigned int block_err = block ^ (1u << 5);
        long int b = (long int)block_err;
        assert(mbe_checkGolayBlock(&b) == 0);
        // mbe_checkGolayBlock returns only the 12-bit data in b
        assert((unsigned int)b == data);

        char code[23];
        for (int j = 0; j < 23; ++j) {
            code[j] = (char)((block >> j) & 1u);
        }
        char err[23];
        memcpy(err, code, sizeof(err));
        flip_bit(err, 22);
        flip_bit(err, 17);
        flip_bit(err, 8);
        flip_bit(err, 2);
        mbe_soft_bit soft[23];
        make_soft_bits(err, soft, 23, 22, 17, 8, 2);
        char fixed[23];
        int soft_errs = mbe_golay2312Soft(soft, fixed);
        assert(soft_errs == 2);
        for (int j = 22; j >= 11; --j) {
            assert(fixed[j] == code[j]);
        }

        memcpy(err, code, sizeof(err));
        flip_bit(err, 5);
        make_soft_bits(err, soft, 23, 5, -1, -1, -1);
        soft_errs = mbe_golay2312Soft(soft, fixed);
        assert(soft_errs == 0);
        for (int j = 22; j >= 11; --j) {
            assert(fixed[j] == code[j]);
        }
        for (int j = 10; j >= 0; --j) {
            assert(fixed[j] == err[j]);
        }
    }

    return 0;
}
